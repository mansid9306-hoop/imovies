import mongoose from 'mongoose';

const seatSchema = new mongoose.Schema(
  {
    seatId: { type: String, required: true }, // e.g., 'A1', 'C5'
    row: { type: String, required: true },    // e.g., 'A'
    col: { type: Number, required: true },    // e.g., 1
    tier: {
      type: String,
      enum: ['vip', 'premium', 'standard'],
      default: 'standard',
    },
    price: { type: Number, required: true },
    status: {
      type: String,
      enum: ['available', 'locked', 'booked'],
      default: 'available',
    },
    lockedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    lockExpiry: {
      type: Date,
      default: null,
    },
  },
  { _id: false }
);

const showSchema = new mongoose.Schema(
  {
    movieId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Movie',
      required: true,
      index: true,
    },
    theatreId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Theatre',
      required: true,
      index: true,
    },
    screenName: {
      type: String,
      required: true,
    },
    showDate: {
      type: String, // Format: YYYY-MM-DD
      required: true,
      index: true,
    },
    showTime: {
      type: String, // e.g. "10:30 AM", "01:45 PM", "05:00 PM", "08:30 PM"
      required: true,
    },
    pricing: {
      vip: { type: Number, default: 350 },
      premium: { type: Number, default: 250 },
      standard: { type: Number, default: 180 },
    },
    seatMatrix: [seatSchema],
    totalSeats: {
      type: Number,
      default: 60,
    },
    availableSeats: {
      type: Number,
      default: 60,
    },
  },
  {
    timestamps: true,
  }
);

// Compound index for querying shows by movie, theatre, date
showSchema.index({ movieId: 1, showDate: 1 });
showSchema.index({ theatreId: 1, showDate: 1 });

/**
 * Utility function to generate a standard 60-seat layout:
 * Rows A-B: VIP (seats 1-10) -> 20 seats
 * Rows C-D: Premium (seats 1-10) -> 20 seats
 * Rows E-F: Standard (seats 1-10) -> 20 seats
 */
export const generateSeatLayout = (pricing = { vip: 350, premium: 250, standard: 180 }) => {
  const seats = [];
  const rows = [
    { name: 'A', tier: 'vip', price: pricing.vip },
    { name: 'B', tier: 'vip', price: pricing.vip },
    { name: 'C', tier: 'premium', price: pricing.premium },
    { name: 'D', tier: 'premium', price: pricing.premium },
    { name: 'E', tier: 'standard', price: pricing.standard },
    { name: 'F', tier: 'standard', price: pricing.standard },
  ];

  for (const row of rows) {
    for (let col = 1; col <= 10; col++) {
      seats.push({
        seatId: `${row.name}${col}`,
        row: row.name,
        col: col,
        tier: row.tier,
        price: row.price,
        status: 'available',
        lockedBy: null,
        lockExpiry: null,
      });
    }
  }

  return seats;
};

const Show = mongoose.model('Show', showSchema);
import { createModelAdapter } from '../utils/memoryStore.js';
export default createModelAdapter('shows', Show);
