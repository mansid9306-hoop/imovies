import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import MovieCard from '../components/MovieCard';
import {
  Film,
  Search,
  Sparkles,
  Ticket,
  Shield,
  Smartphone,
  Tv,
  Play,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

const HomePage = ({ selectedCity }) => {
  const [movies, setMovies] = useState([]);
  const [featuredMovie, setFeaturedMovie] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [loading, setLoading] = useState(true);

  const genres = ['all', 'Action', 'Sci-Fi', 'Adventure', 'Drama', 'Animation'];

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        setLoading(true);
        const res = await api.get('/movies');
        if (res.data.success) {
          setMovies(res.data.data);
          // Pick Dune or top rated as featured
          const featured = res.data.data.find((m) => m.title.includes('Dune')) || res.data.data[0];
          setFeaturedMovie(featured);
        }
      } catch (err) {
        console.error('Failed to load movies', err);
      } finally {
        setLoading(false);
      }
    };
    fetchMovies();
  }, []);

  const filteredMovies = movies.filter((m) => {
    const matchesSearch =
      m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.director?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.genre?.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesGenre =
      selectedGenre === 'all' || m.genre?.some((g) => g.toLowerCase() === selectedGenre.toLowerCase());

    return matchesSearch && matchesGenre;
  });

  const nowShowing = filteredMovies.filter((m) => m.status === 'now_showing');
  const upcoming = filteredMovies.filter((m) => m.status === 'upcoming');

  return (
    <div className="container py-4">
      {/* Hero Spotlight Banner */}
      {featuredMovie && (
        <div
          className="hero-banner p-4 p-md-5 position-relative shadow-2xl"
          style={{
            backgroundImage: `url(${featuredMovie.banner || featuredMovie.poster})`,
          }}
        >
          <div className="hero-overlay"></div>
          <div className="position-relative text-white" style={{ maxWidth: '640px', zIndex: 2 }}>
            <div className="d-inline-flex align-items-center gap-2 mb-3">
              <span className="badge badge-gold d-flex align-items-center gap-1">
                <Sparkles size={13} /> SPOTLIGHT BLOCKBUSTER
              </span>
              <span className="badge badge-red">{featuredMovie.certificate || 'UA'}</span>
              <span className="text-secondary small">★ {featuredMovie.rating}/10</span>
            </div>

            <h1 className="display-4 fw-black text-white mb-2">{featuredMovie.title}</h1>
            <p className="text-light text-opacity-75 mb-3 line-clamp-3" style={{ fontSize: '15px' }}>
              {featuredMovie.description}
            </p>

            <div className="d-flex flex-wrap gap-2 mb-4">
              {featuredMovie.genre?.map((g) => (
                <span
                  key={g}
                  className="badge px-3 py-1.5"
                  style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)' }}
                >
                  {g}
                </span>
              ))}
              <span className="badge px-3 py-1.5 bg-dark bg-opacity-50">
                {featuredMovie.duration} mins
              </span>
            </div>

            <div className="d-flex flex-wrap gap-3">
              <Link
                to={`/movies/${featuredMovie._id}`}
                className="btn glow-btn px-4 py-2 d-flex align-items-center gap-2"
              >
                <Ticket size={18} /> Book Tickets Now
              </Link>
              {featuredMovie.trailerUrl && (
                <a
                  href={featuredMovie.trailerUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-outline-light px-4 py-2 d-flex align-items-center gap-2"
                >
                  <Play size={18} /> Watch Trailer
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quick Search & Genre Filter Toolbar */}
      <div className="cinema-card p-3 p-md-4 mb-5">
        <div className="row g-3 align-items-center">
          <div className="col-12 col-md-5">
            <div className="position-relative">
              <Search
                size={18}
                className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
              />
              <input
                type="text"
                className="form-control cinema-input ps-5"
                placeholder="Search movies, actors, directors..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="col-12 col-md-7">
            <div className="d-flex flex-wrap gap-2 justify-content-md-end">
              {genres.map((genre) => (
                <button
                  key={genre}
                  type="button"
                  className={`btn btn-sm rounded-pill px-3 py-1.5 transition ${
                    selectedGenre === genre
                      ? 'glow-btn'
                      : 'btn-outline-secondary text-light'
                  }`}
                  onClick={() => setSelectedGenre(genre)}
                >
                  {genre === 'all' ? 'All Genres' : genre}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Now Showing Section */}
      <div className="mb-5">
        <div className="d-flex justify-content-between align-items-end mb-4">
          <div>
            <div className="d-flex align-items-center gap-2 mb-1">
              <TrendingUp size={20} className="text-danger" />
              <h3 className="fw-black text-white mb-0">Now Showing</h3>
            </div>
            <p className="text-secondary small mb-0">
              Catch the biggest cinema blockbusters playing in theatres near you
            </p>
          </div>
          <Link to="/movies" className="text-danger text-decoration-none small fw-bold d-flex align-items-center gap-1 hover-white">
            View All <ArrowRight size={14} />
          </Link>
        </div>

        {loading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-danger" role="status"></div>
          </div>
        ) : nowShowing.length === 0 ? (
          <div className="cinema-card p-5 text-center">
            <Film size={48} className="text-secondary mb-3" />
            <h5 className="text-white">No movies match your search</h5>
            <p className="text-secondary small">Try adjusting your filters or search keywords.</p>
          </div>
        ) : (
          <div className="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
            {nowShowing.map((movie) => (
              <div key={movie._id} className="col">
                <MovieCard movie={movie} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Upcoming Releases Section */}
      {upcoming.length > 0 && (
        <div className="mb-5">
          <div className="d-flex justify-content-between align-items-end mb-4">
            <div>
              <h3 className="fw-black text-white mb-1">Upcoming Releases</h3>
              <p className="text-secondary small mb-0">Be the first to explore advance bookings & trailers</p>
            </div>
          </div>

          <div className="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
            {upcoming.map((movie) => (
              <div key={movie._id} className="col">
                <MovieCard movie={movie} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Why Choose IMovies Experience Section */}
      <div className="cinema-card p-4 p-md-5 my-5">
        <div className="text-center mb-5">
          <h3 className="fw-black text-white mb-2">The Ultimate Cinema Experience</h3>
          <p className="text-secondary" style={{ maxWidth: '580px', margin: '0 auto' }}>
            IMovies connects you directly with premium theatres, contactless mobile ticketing, and real-time seat tracking.
          </p>
        </div>

        <div className="row g-4 text-center">
          <div className="col-12 col-md-3">
            <div
              className="d-inline-flex p-3 rounded-circle mb-3"
              style={{ background: 'rgba(229, 9, 20, 0.15)', color: '#e50914' }}
            >
              <Ticket size={28} />
            </div>
            <h6 className="text-white fw-bold mb-2">Instant QR E-Tickets</h6>
            <p className="text-secondary small mb-0">
              Fast, paperless entrance. Show your QR ticket directly on your mobile device.
            </p>
          </div>

          <div className="col-12 col-md-3">
            <div
              className="d-inline-flex p-3 rounded-circle mb-3"
              style={{ background: 'rgba(59, 130, 246, 0.15)', color: '#3b82f6' }}
            >
              <Smartphone size={28} />
            </div>
            <h6 className="text-white fw-bold mb-2">Live Real-Time Seats</h6>
            <p className="text-secondary small mb-0">
              Interactive 60-seat auditorium layout with live seat locking and zero double-booking.
            </p>
          </div>

          <div className="col-12 col-md-3">
            <div
              className="d-inline-flex p-3 rounded-circle mb-3"
              style={{ background: 'rgba(245, 158, 11, 0.15)', color: '#f59e0b' }}
            >
              <Tv size={28} />
            </div>
            <h6 className="text-white fw-bold mb-2">IMAX & Dolby Atmos</h6>
            <p className="text-secondary small mb-0">
              Choose from VIP recliners, IMAX Laser 3D, and immersive Dolby Atmos auditoriums.
            </p>
          </div>

          <div className="col-12 col-md-3">
            <div
              className="d-inline-flex p-3 rounded-circle mb-3"
              style={{ background: 'rgba(16, 185, 129, 0.15)', color: '#10b981' }}
            >
              <Shield size={28} />
            </div>
            <h6 className="text-white fw-bold mb-2">Flexible Cancellation</h6>
            <p className="text-secondary small mb-0">
              Plans changed? Cancel your ticket easily with automatic refund processing.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
