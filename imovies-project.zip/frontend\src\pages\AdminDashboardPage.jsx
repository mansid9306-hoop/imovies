import React, { useState, useEffect } from 'react';
import api from '../services/api';
import {
  DollarSign,
  Ticket,
  Film,
  Compass,
  Users,
  PlusCircle,
  Calendar,
  Clock,
  Trash2,
  TrendingUp,
  ShieldCheck,
  CheckCircle,
  XCircle,
} from 'lucide-react';

const AdminDashboardPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [movies, setMovies] = useState([]);
  const [theatres, setTheatres] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('analytics');

  // New Movie Form Modal State
  const [showAddMovieModal, setShowAddMovieModal] = useState(false);
  const [newMovie, setNewMovie] = useState({
    title: '',
    description: '',
    genre: 'Action, Sci-Fi',
    language: 'English, Hindi',
    duration: 150,
    releaseDate: new Date().toISOString().split('T')[0],
    poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1400&q=80',
    trailerUrl: 'https://www.youtube.com/embed/Way9Dexny3w',
    rating: 8.5,
    certificate: 'UA',
    status: 'now_showing',
    director: 'Christopher Nolan',
  });

  // Schedule Show State
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [newShow, setNewShow] = useState({
    movieId: '',
    theatreId: '',
    screenName: 'Audi 1 - IMAX Laser',
    showDate: new Date().toISOString().split('T')[0],
    showTime: '06:15 PM',
    vipPrice: 450,
    premiumPrice: 300,
    standardPrice: 200,
  });

  const [actionSuccess, setActionSuccess] = useState('');

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [analyticsRes, moviesRes, theatresRes, bookingsRes] = await Promise.all([
        api.get('/admin/analytics'),
        api.get('/movies?limit=50'),
        api.get('/theatres'),
        api.get('/bookings?limit=30'),
      ]);

      if (analyticsRes.data.success) setAnalytics(analyticsRes.data.data);
      if (moviesRes.data.success) {
        setMovies(moviesRes.data.data);
        if (moviesRes.data.data.length > 0 && !newShow.movieId) {
          setNewShow((prev) => ({ ...prev, movieId: moviesRes.data.data[0]._id }));
        }
      }
      if (theatresRes.data.success) {
        setTheatres(theatresRes.data.data);
        if (theatresRes.data.data.length > 0 && !newShow.theatreId) {
          setNewShow((prev) => ({ ...prev, theatreId: theatresRes.data.data[0]._id }));
        }
      }
      if (bookingsRes.data.success) setBookings(bookingsRes.data.data);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Add Movie Handler
  const handleAddMovie = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...newMovie,
        genre: newMovie.genre.split(',').map((s) => s.trim()),
        language: newMovie.language.split(',').map((s) => s.trim()),
        duration: Number(newMovie.duration),
        rating: Number(newMovie.rating),
      };

      const res = await api.post('/movies', payload);
      if (res.data.success) {
        setActionSuccess(`Movie "${newMovie.title}" added successfully!`);
        setShowAddMovieModal(false);
        fetchDashboardData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to add movie');
    }
  };

  // Schedule Show Handler
  const handleScheduleShow = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        movieId: newShow.movieId,
        theatreId: newShow.theatreId,
        screenName: newShow.screenName,
        showDate: newShow.showDate,
        showTime: newShow.showTime,
        pricing: {
          vip: Number(newShow.vipPrice),
          premium: Number(newShow.premiumPrice),
          standard: Number(newShow.standardPrice),
        },
      };

      const res = await api.post('/shows', payload);
      if (res.data.success) {
        setActionSuccess(`Show successfully scheduled for ${newShow.showDate} at ${newShow.showTime}!`);
        setShowScheduleModal(false);
        fetchDashboardData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to schedule show');
    }
  };

  // Delete Movie Handler
  const handleDeleteMovie = async (id, title) => {
    if (!window.confirm(`Are you sure you want to delete "${title}"? Associated shows will also be removed.`)) {
      return;
    }
    try {
      const res = await api.delete(`/movies/${id}`);
      if (res.data.success) {
        setActionSuccess(`Movie "${title}" deleted.`);
        fetchDashboardData();
      }
    } catch (err) {
      alert('Failed to delete movie');
    }
  };

  if (loading) {
    return (
      <div className="d-flex align-items-center justify-content-center min-vh-50 py-5">
        <div className="spinner-border text-danger" role="status"></div>
      </div>
    );
  }

  const stats = analytics?.stats || {};

  return (
    <div className="container py-4">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary border-opacity-25">
        <div>
          <div className="d-flex align-items-center gap-2">
            <ShieldCheck size={24} className="text-warning" />
            <h2 className="fw-black text-white mb-0">Cinema Administration</h2>
          </div>
          <p className="text-secondary small mb-0">
            Real-time analytics, movie catalogs, theatre schedules & booking management
          </p>
        </div>

        <div className="d-flex flex-wrap gap-2">
          <button
            className="btn glow-btn btn-sm d-flex align-items-center gap-1.5"
            onClick={() => setShowAddMovieModal(true)}
          >
            <PlusCircle size={15} /> Add Movie
          </button>
          <button
            className="btn glow-btn-gold btn-sm d-flex align-items-center gap-1.5"
            onClick={() => setShowScheduleModal(true)}
          >
            <Calendar size={15} /> Schedule Show
          </button>
        </div>
      </div>

      {actionSuccess && (
        <div className="alert alert-success d-flex align-items-center justify-content-between mb-4">
          <div className="d-flex align-items-center gap-2">
            <CheckCircle size={18} />
            <span>{actionSuccess}</span>
          </div>
          <button
            type="button"
            className="btn-close"
            onClick={() => setActionSuccess('')}
          ></button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="row row-cols-2 row-cols-lg-4 g-3 mb-4">
        <div className="col">
          <div className="cinema-card p-3 p-md-4">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="text-secondary small text-uppercase fw-bold">Total Revenue</span>
              <div className="p-2 rounded-circle bg-success bg-opacity-10 text-success">
                <DollarSign size={20} />
              </div>
            </div>
            <h3 className="fw-black text-white mb-1">₹{stats.totalRevenue?.toLocaleString()}</h3>
            <span className="text-success small fw-semibold">↑ Online Transactions</span>
          </div>
        </div>

        <div className="col">
          <div className="cinema-card p-3 p-md-4">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="text-secondary small text-uppercase fw-bold">Tickets Sold</span>
              <div className="p-2 rounded-circle bg-danger bg-opacity-10 text-danger">
                <Ticket size={20} />
              </div>
            </div>
            <h3 className="fw-black text-white mb-1">{stats.totalTicketsSold}</h3>
            <span className="text-secondary small">{stats.confirmedBookings} Confirmed Orders</span>
          </div>
        </div>

        <div className="col">
          <div className="cinema-card p-3 p-md-4">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="text-secondary small text-uppercase fw-bold">Active Movies</span>
              <div className="p-2 rounded-circle bg-primary bg-opacity-10 text-primary">
                <Film size={20} />
              </div>
            </div>
            <h3 className="fw-black text-white mb-1">{stats.totalMovies}</h3>
            <span className="text-secondary small">{stats.totalShows} Scheduled Shows</span>
          </div>
        </div>

        <div className="col">
          <div className="cinema-card p-3 p-md-4">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <span className="text-secondary small text-uppercase fw-bold">Registered Users</span>
              <div className="p-2 rounded-circle bg-warning bg-opacity-10 text-warning">
                <Users size={20} />
              </div>
            </div>
            <h3 className="fw-black text-white mb-1">{stats.totalUsers}</h3>
            <span className="text-secondary small">{theatres.length} Partner Theatres</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="d-flex gap-2 mb-4">
        <button
          className={`btn btn-sm px-4 py-2 rounded-pill transition ${
            activeTab === 'analytics' ? 'glow-btn' : 'btn-outline-secondary text-light'
          }`}
          onClick={() => setActiveTab('analytics')}
        >
          Overview & Insights
        </button>
        <button
          className={`btn btn-sm px-4 py-2 rounded-pill transition ${
            activeTab === 'movies' ? 'glow-btn' : 'btn-outline-secondary text-light'
          }`}
          onClick={() => setActiveTab('movies')}
        >
          Movie Catalog ({movies.length})
        </button>
        <button
          className={`btn btn-sm px-4 py-2 rounded-pill transition ${
            activeTab === 'bookings' ? 'glow-btn' : 'btn-outline-secondary text-light'
          }`}
          onClick={() => setActiveTab('bookings')}
        >
          Bookings Log ({bookings.length})
        </button>
      </div>

      {/* Overview Tab */}
      {activeTab === 'analytics' && (
        <div className="row g-4">
          {/* Top Grossing Movies */}
          <div className="col-12 col-lg-6">
            <div className="cinema-card p-4 h-100">
              <div className="d-flex align-items-center gap-2 mb-3">
                <TrendingUp size={18} className="text-warning" />
                <h5 className="text-white fw-bold mb-0">Top Grossing Movies</h5>
              </div>

              {analytics?.topMovies?.length === 0 ? (
                <p className="text-secondary small">No booking transactions recorded yet.</p>
              ) : (
                <div className="d-flex flex-column gap-3">
                  {analytics?.topMovies?.map((tm, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded bg-dark bg-opacity-50 d-flex justify-content-between align-items-center border border-secondary border-opacity-25"
                    >
                      <div className="d-flex align-items-center gap-3">
                        <span className="fw-black text-secondary fs-5">#{idx + 1}</span>
                        <div>
                          <strong className="text-white d-block">{tm.title}</strong>
                          <span className="text-secondary small">{tm.tickets} tickets sold</span>
                        </div>
                      </div>
                      <span className="text-success fw-black fs-5">₹{tm.revenue}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recent Bookings Feed */}
          <div className="col-12 col-lg-6">
            <div className="cinema-card p-4 h-100">
              <h5 className="text-white fw-bold mb-3">Recent Ticket Transactions</h5>
              <div className="d-flex flex-column gap-2" style={{ maxHeight: '350px', overflowY: 'auto' }}>
                {bookings.slice(0, 6).map((b) => (
                  <div
                    key={b._id}
                    className="p-2.5 rounded bg-dark bg-opacity-50 d-flex justify-content-between align-items-center border border-secondary border-opacity-25"
                  >
                    <div>
                      <strong className="text-white small d-block">{b.movieId?.title}</strong>
                      <span className="text-secondary" style={{ fontSize: '11px' }}>
                        {b.userId?.name} • Seats: {b.seats?.join(', ')}
                      </span>
                    </div>
                    <div className="text-end">
                      <span className="text-warning small fw-bold d-block">₹{b.totalAmount}</span>
                      <span
                        className={`badge ${
                          b.bookingStatus === 'confirmed' ? 'badge-blue' : 'badge-red'
                        }`}
                        style={{ fontSize: '9px' }}
                      >
                        {b.bookingStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Movies Tab */}
      {activeTab === 'movies' && (
        <div className="cinema-card p-4">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h5 className="text-white fw-bold mb-0">All Catalog Movies</h5>
            <button
              className="btn glow-btn btn-sm d-flex align-items-center gap-1.5"
              onClick={() => setShowAddMovieModal(true)}
            >
              <PlusCircle size={15} /> Add New Movie
            </button>
          </div>

          <div className="table-responsive">
            <table className="table table-dark table-hover mb-0 align-middle">
              <thead>
                <tr className="text-secondary small text-uppercase">
                  <th>Poster</th>
                  <th>Title</th>
                  <th>Genre</th>
                  <th>Rating</th>
                  <th>Duration</th>
                  <th>Status</th>
                  <th className="text-end">Actions</th>
                </tr>
              </thead>
              <tbody>
                {movies.map((m) => (
                  <tr key={m._id}>
                    <td>
                      <img
                        src={m.poster}
                        alt={m.title}
                        className="rounded"
                        style={{ width: '40px', height: '55px', objectFit: 'cover' }}
                      />
                    </td>
                    <td>
                      <strong className="text-white d-block">{m.title}</strong>
                      <span className="text-secondary small">{m.director}</span>
                    </td>
                    <td>
                      <span className="text-light small">{m.genre?.join(', ')}</span>
                    </td>
                    <td>
                      <span className="badge badge-gold">★ {m.rating}</span>
                    </td>
                    <td>{m.duration} mins</td>
                    <td>
                      <span
                        className={`badge ${
                          m.status === 'now_showing' ? 'badge-blue' : 'badge-red'
                        }`}
                      >
                        {m.status}
                      </span>
                    </td>
                    <td className="text-end">
                      <button
                        className="btn btn-sm btn-outline-danger p-1.5 rounded"
                        title="Delete Movie"
                        onClick={() => handleDeleteMovie(m._id, m.title)}
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <div className="cinema-card p-4">
          <h5 className="text-white fw-bold mb-4">Live Customer Bookings Log</h5>
          <div className="table-responsive">
            <table className="table table-dark table-hover mb-0 align-middle">
              <thead>
                <tr className="text-secondary small text-uppercase">
                  <th>Ref #</th>
                  <th>Customer</th>
                  <th>Movie</th>
                  <th>Theatre</th>
                  <th>Seats</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b._id}>
                    <td className="font-monospace text-warning small">{b.bookingNumber}</td>
                    <td>
                      <strong className="text-white small d-block">{b.userId?.name}</strong>
                      <span className="text-secondary" style={{ fontSize: '11px' }}>
                        {b.userId?.email}
                      </span>
                    </td>
                    <td className="text-white">{b.movieId?.title}</td>
                    <td className="text-secondary small">{b.theatreId?.name}</td>
                    <td>
                      <span className="badge badge-gold">{b.seats?.join(', ')}</span>
                    </td>
                    <td className="text-success fw-bold">₹{b.totalAmount}</td>
                    <td>
                      <span
                        className={`badge ${
                          b.bookingStatus === 'confirmed' ? 'badge-blue' : 'badge-red'
                        }`}
                      >
                        {b.bookingStatus?.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Movie Modal */}
      {showAddMovieModal && (
        <div
          className="modal fade show d-block"
          tabIndex="-1"
          style={{ backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)', zIndex: 1060 }}
        >
          <div className="modal-dialog modal-dialog-centered modal-lg">
            <div className="modal-content cinema-modal border-0 p-4 shadow-2xl">
              <div className="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom border-secondary border-opacity-25">
                <h5 className="modal-title fw-bold text-white mb-0">Add New Movie to Catalog</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setShowAddMovieModal(false)}
                ></button>
              </div>

              <form onSubmit={handleAddMovie}>
                <div className="row g-3">
                  <div className="col-12 col-md-8">
                    <label className="text-secondary small mb-1">Movie Title</label>
                    <input
                      type="text"
                      className="form-control cinema-input"
                      value={newMovie.title}
                      onChange={(e) => setNewMovie({ ...newMovie, title: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-12 col-md-4">
                    <label className="text-secondary small mb-1">Certificate</label>
                    <select
                      className="form-select cinema-input text-white"
                      value={newMovie.certificate}
                      onChange={(e) => setNewMovie({ ...newMovie, certificate: e.target.value })}
                    >
                      <option value="U">U (Universal)</option>
                      <option value="UA">UA (Parental Guidance)</option>
                      <option value="A">A (Adults 18+)</option>
                    </select>
                  </div>

                  <div className="col-12">
                    <label className="text-secondary small mb-1">Synopsis / Description</label>
                    <textarea
                      rows={3}
                      className="form-control cinema-input"
                      value={newMovie.description}
                      onChange={(e) => setNewMovie({ ...newMovie, description: e.target.value })}
                      required
                    ></textarea>
                  </div>

                  <div className="col-12 col-sm-6">
                    <label className="text-secondary small mb-1">Genres (comma separated)</label>
                    <input
                      type="text"
                      className="form-control cinema-input"
                      value={newMovie.genre}
                      onChange={(e) => setNewMovie({ ...newMovie, genre: e.target.value })}
                      placeholder="Action, Sci-Fi, Thriller"
                      required
                    />
                  </div>

                  <div className="col-12 col-sm-6">
                    <label className="text-secondary small mb-1">Languages (comma separated)</label>
                    <input
                      type="text"
                      className="form-control cinema-input"
                      value={newMovie.language}
                      onChange={(e) => setNewMovie({ ...newMovie, language: e.target.value })}
                      placeholder="English, Hindi"
                      required
                    />
                  </div>

                  <div className="col-6 col-sm-4">
                    <label className="text-secondary small mb-1">Duration (minutes)</label>
                    <input
                      type="number"
                      className="form-control cinema-input"
                      value={newMovie.duration}
                      onChange={(e) => setNewMovie({ ...newMovie, duration: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-6 col-sm-4">
                    <label className="text-secondary small mb-1">Rating (out of 10)</label>
                    <input
                      type="number"
                      step="0.1"
                      className="form-control cinema-input"
                      value={newMovie.rating}
                      onChange={(e) => setNewMovie({ ...newMovie, rating: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-12 col-sm-4">
                    <label className="text-secondary small mb-1">Status</label>
                    <select
                      className="form-select cinema-input text-white"
                      value={newMovie.status}
                      onChange={(e) => setNewMovie({ ...newMovie, status: e.target.value })}
                    >
                      <option value="now_showing">Now Showing</option>
                      <option value="upcoming">Upcoming</option>
                    </select>
                  </div>

                  <div className="col-12 col-sm-6">
                    <label className="text-secondary small mb-1">Poster Image URL</label>
                    <input
                      type="url"
                      className="form-control cinema-input"
                      value={newMovie.poster}
                      onChange={(e) => setNewMovie({ ...newMovie, poster: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-12 col-sm-6">
                    <label className="text-secondary small mb-1">Backdrop Banner URL</label>
                    <input
                      type="url"
                      className="form-control cinema-input"
                      value={newMovie.banner}
                      onChange={(e) => setNewMovie({ ...newMovie, banner: e.target.value })}
                    />
                  </div>

                  <div className="col-12">
                    <label className="text-secondary small mb-1">Trailer YouTube Embed URL</label>
                    <input
                      type="url"
                      className="form-control cinema-input"
                      value={newMovie.trailerUrl}
                      onChange={(e) => setNewMovie({ ...newMovie, trailerUrl: e.target.value })}
                    />
                  </div>
                </div>

                <div className="d-flex justify-content-end gap-2 mt-4 pt-3 border-top border-secondary border-opacity-25">
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => setShowAddMovieModal(false)}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn glow-btn btn-sm px-4">
                    Save Movie
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Show Modal */}
      {showScheduleModal && (
        <div
          className="modal fade show d-block"
          tabIndex="-1"
          style={{ backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)', zIndex: 1060 }}
        >
          <div className="modal-dialog modal-dialog-centered modal-lg">
            <div className="modal-content cinema-modal border-0 p-4 shadow-2xl">
              <div className="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom border-secondary border-opacity-25">
                <h5 className="modal-title fw-bold text-white mb-0">Schedule New Cinema Show</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setShowScheduleModal(false)}
                ></button>
              </div>

              <form onSubmit={handleScheduleShow}>
                <div className="row g-3">
                  <div className="col-12 col-md-6">
                    <label className="text-secondary small mb-1">Select Movie</label>
                    <select
                      className="form-select cinema-input text-white"
                      value={newShow.movieId}
                      onChange={(e) => setNewShow({ ...newShow, movieId: e.target.value })}
                      required
                    >
                      {movies.map((m) => (
                        <option key={m._id} value={m._id}>
                          {m.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-12 col-md-6">
                    <label className="text-secondary small mb-1">Select Cinema Theatre</label>
                    <select
                      className="form-select cinema-input text-white"
                      value={newShow.theatreId}
                      onChange={(e) => setNewShow({ ...newShow, theatreId: e.target.value })}
                      required
                    >
                      {theatres.map((t) => (
                        <option key={t._id} value={t._id}>
                          {t.name} ({t.city})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-12 col-sm-4">
                    <label className="text-secondary small mb-1">Screen / Auditorium</label>
                    <input
                      type="text"
                      className="form-control cinema-input"
                      value={newShow.screenName}
                      onChange={(e) => setNewShow({ ...newShow, screenName: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-12 col-sm-4">
                    <label className="text-secondary small mb-1">Date</label>
                    <input
                      type="date"
                      className="form-control cinema-input"
                      value={newShow.showDate}
                      onChange={(e) => setNewShow({ ...newShow, showDate: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-12 col-sm-4">
                    <label className="text-secondary small mb-1">Time Slot</label>
                    <select
                      className="form-select cinema-input text-white"
                      value={newShow.showTime}
                      onChange={(e) => setNewShow({ ...newShow, showTime: e.target.value })}
                    >
                      <option value="10:30 AM">10:30 AM (Morning)</option>
                      <option value="02:00 PM">02:00 PM (Matinee)</option>
                      <option value="06:15 PM">06:15 PM (Evening)</option>
                      <option value="09:45 PM">09:45 PM (Night)</option>
                    </select>
                  </div>

                  {/* Pricing Tiers */}
                  <div className="col-12 mt-3">
                    <label className="text-secondary small d-block mb-2">Auditorium Tier Pricing (INR):</label>
                    <div className="row g-2">
                      <div className="col-4">
                        <label className="text-warning small mb-1">VIP Recliner</label>
                        <input
                          type="number"
                          className="form-control cinema-input"
                          value={newShow.vipPrice}
                          onChange={(e) => setNewShow({ ...newShow, vipPrice: e.target.value })}
                          required
                        />
                      </div>
                      <div className="col-4">
                        <label className="text-primary small mb-1">Premium Club</label>
                        <input
                          type="number"
                          className="form-control cinema-input"
                          value={newShow.premiumPrice}
                          onChange={(e) => setNewShow({ ...newShow, premiumPrice: e.target.value })}
                          required
                        />
                      </div>
                      <div className="col-4">
                        <label className="text-danger small mb-1">Standard Classic</label>
                        <input
                          type="number"
                          className="form-control cinema-input"
                          value={newShow.standardPrice}
                          onChange={(e) => setNewShow({ ...newShow, standardPrice: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="d-flex justify-content-end gap-2 mt-4 pt-3 border-top border-secondary border-opacity-25">
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => setShowScheduleModal(false)}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn glow-btn btn-sm px-4">
                    Schedule & Generate Seats
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboardPage;
