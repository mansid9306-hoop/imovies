import bcrypt from 'bcryptjs';

// Generate a valid 24-character hex string similar to MongoDB ObjectId
export const generateObjectId = () => {
  const timestamp = Math.floor(Date.now() / 1000).toString(16).padStart(8, '0');
  const random = Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
  return `${timestamp}${random}`;
};

class MemoryCollection {
  constructor(name) {
    this.name = name;
    this.documents = [];
  }

  _matches(doc, query = {}) {
    if (!query || Object.keys(query).length === 0) return true;

    for (const [key, val] of Object.entries(query)) {
      if (key === '$or') {
        const anyMatch = val.some((subQuery) => this._matches(doc, subQuery));
        if (!anyMatch) return false;
        continue;
      }

      const docVal = doc[key];

      if (val instanceof RegExp) {
        if (!val.test(String(docVal || ''))) return false;
      } else if (typeof val === 'object' && val !== null) {
        if ('$regex' in val) {
          const options = val.$options || '';
          const reg = new RegExp(val.$regex, options);
          if (!reg.test(String(docVal || ''))) return false;
        } else if ('$in' in val) {
          if (Array.isArray(docVal)) {
            const hasMatch = val.$in.some((item) =>
              item instanceof RegExp
                ? docVal.some((d) => item.test(d))
                : docVal.includes(item)
            );
            if (!hasMatch) return false;
          } else {
            if (!val.$in.includes(docVal)) return false;
          }
        }
      } else {
        // String or primitive compare (handling string ObjectId)
        if (String(docVal) !== String(val)) return false;
      }
    }

    return true;
  }

  _wrapDoc(rawDoc) {
    if (!rawDoc) return null;
    const doc = { ...rawDoc };

    doc.toObject = function () {
      return { ...this };
    };

    doc.save = async function () {
      doc.updatedAt = new Date();
      return doc;
    };

    doc.deleteOne = async () => {
      this.documents = this.documents.filter((d) => String(d._id) !== String(doc._id));
      return { deletedCount: 1 };
    };

    if (this.name === 'users') {
      doc.matchPassword = async function (enteredPassword) {
        return await bcrypt.compare(enteredPassword, this.password);
      };
    }

    return doc;
  }

  find(query = {}) {
    const matched = this.documents
      .filter((d) => this._matches(d, query))
      .map((d) => this._wrapDoc(d));

    return new QueryCursor(matched, this);
  }

  findOne(query = {}) {
    const doc = this.documents.find((d) => this._matches(d, query));
    return new QueryCursorSingle(doc ? this._wrapDoc(doc) : null, this);
  }

  findById(id) {
    const doc = this.documents.find((d) => String(d._id) === String(id));
    return new QueryCursorSingle(doc ? this._wrapDoc(doc) : null, this);
  }

  async create(data) {
    const doc = { ...data };
    doc._id = doc._id || generateObjectId();
    doc.createdAt = new Date();
    doc.updatedAt = new Date();

    if (this.name === 'users' && doc.password) {
      if (!doc.password.startsWith('$2a$') && !doc.password.startsWith('$2b$')) {
        const salt = await bcrypt.genSalt(10);
        doc.password = await bcrypt.hash(doc.password, salt);
      }
    }

    this.documents.push(doc);
    return this._wrapDoc(doc);
  }

  async insertMany(items) {
    const created = [];
    for (const item of items) {
      const doc = await this.create(item);
      created.push(doc);
    }
    return created;
  }

  async findByIdAndUpdate(id, update, options = {}) {
    const index = this.documents.findIndex((d) => String(d._id) === String(id));
    if (index === -1) return null;

    if (update.$set) {
      this.documents[index] = { ...this.documents[index], ...update.$set };
    } else {
      this.documents[index] = { ...this.documents[index], ...update };
    }
    this.documents[index].updatedAt = new Date();

    return this._wrapDoc(this.documents[index]);
  }

  async findOneAndUpdate(query, update, options = {}) {
    const doc = this.documents.find((d) => this._matches(d, query));
    if (!doc) return null;
    return this.findByIdAndUpdate(doc._id, update, options);
  }

  async deleteMany(query = {}) {
    const initial = this.documents.length;
    this.documents = this.documents.filter((d) => !this._matches(d, query));
    return { deletedCount: initial - this.documents.length };
  }

  async countDocuments(query = {}) {
    return this.documents.filter((d) => this._matches(d, query)).length;
  }

  async distinct(field) {
    const set = new Set();
    this.documents.forEach((d) => {
      const val = d[field];
      if (Array.isArray(val)) {
        val.forEach((item) => set.add(item));
      } else if (val !== undefined && val !== null) {
        set.add(val);
      }
    });
    return Array.from(set);
  }

  async aggregate(pipeline = []) {
    let result = [...this.documents];

    for (const stage of pipeline) {
      if (stage.$match) {
        result = result.filter((d) => this._matches(d, stage.$match));
      } else if (stage.$group) {
        const groups = {};
        for (const item of result) {
          const groupId = String(item[stage.$group._id.replace('$', '')] || 'all');
          if (!groups[groupId]) {
            groups[groupId] = {
              _id: item[stage.$group._id.replace('$', '')],
              revenue: 0,
              tickets: 0,
              bookingsCount: 0,
            };
          }
          groups[groupId].revenue += item.totalAmount || 0;
          groups[groupId].tickets += item.seats?.length || 0;
          groups[groupId].bookingsCount += 1;
        }
        result = Object.values(groups);
      } else if (stage.$sort) {
        const [field, dir] = Object.entries(stage.$sort)[0];
        result.sort((a, b) => (dir === -1 ? b[field] - a[field] : a[field] - b[field]));
      } else if (stage.$limit) {
        result = result.slice(0, stage.$limit);
      } else if (stage.$lookup) {
        const targetCollection = memoryStore.getCollection(stage.$lookup.from);
        for (const item of result) {
          const foreignDoc = targetCollection.documents.find(
            (d) => String(d._id) === String(item._id)
          );
          item[stage.$lookup.as] = foreignDoc ? [foreignDoc] : [];
        }
      } else if (stage.$unwind) {
        const fieldName = stage.$unwind.replace('$', '');
        result = result.map((item) => ({
          ...item,
          [fieldName]: Array.isArray(item[fieldName]) ? item[fieldName][0] : item[fieldName],
        }));
      } else if (stage.$project) {
        result = result.map((item) => {
          const proj = { _id: item._id };
          for (const [key, expr] of Object.entries(stage.$project)) {
            if (expr === 1) proj[key] = item[key];
            else if (typeof expr === 'string' && expr.startsWith('$')) {
              const path = expr.replace('$', '').split('.');
              let cur = item;
              for (const p of path) cur = cur ? cur[p] : undefined;
              proj[key] = cur;
            }
          }
          return proj;
        });
      }
    }

    return result;
  }
}

class QueryCursorSingle {
  constructor(doc, collection) {
    this.doc = doc;
    this.collection = collection;
  }

  populate(field, select) {
    if (!this.doc) return this;
    const targetName =
      field === 'movieId'
        ? 'movies'
        : field === 'theatreId'
        ? 'theatres'
        : field === 'showId'
        ? 'shows'
        : field === 'userId'
        ? 'users'
        : field === 'paymentId'
        ? 'payments'
        : null;

    if (targetName && this.doc[field]) {
      const refCol = memoryStore.getCollection(targetName);
      const foreign = refCol.documents.find((d) => String(d._id) === String(this.doc[field]));
      if (foreign) {
        this.doc[field] = { ...foreign };
      }
    }
    return this;
  }

  select(fields) {
    return this;
  }

  then(resolve, reject) {
    return Promise.resolve(this.doc).then(resolve, reject);
  }
}

class QueryCursor {
  constructor(docs, collection) {
    this.docs = docs;
    this.collection = collection;
  }

  sort(sortCriteria = {}) {
    const entries = Object.entries(sortCriteria);
    if (entries.length > 0) {
      const [key, order] = entries[0];
      this.docs.sort((a, b) => {
        if (a[key] < b[key]) return order === -1 ? 1 : -1;
        if (a[key] > b[key]) return order === -1 ? -1 : 1;
        return 0;
      });
    }
    return this;
  }

  skip(num = 0) {
    this.docs = this.docs.slice(num);
    return this;
  }

  limit(num = 0) {
    if (num > 0) {
      this.docs = this.docs.slice(0, num);
    }
    return this;
  }

  populate(field, select) {
    const targetName =
      field === 'movieId'
        ? 'movies'
        : field === 'theatreId'
        ? 'theatres'
        : field === 'showId'
        ? 'shows'
        : field === 'userId'
        ? 'users'
        : field === 'paymentId'
        ? 'payments'
        : null;

    if (targetName) {
      const refCol = memoryStore.getCollection(targetName);
      this.docs.forEach((doc) => {
        if (doc[field]) {
          const foreign = refCol.documents.find((d) => String(d._id) === String(doc[field]));
          if (foreign) {
            doc[field] = { ...foreign };
          }
        }
      });
    }
    return this;
  }

  select(fields) {
    return this;
  }

  then(resolve, reject) {
    return Promise.resolve(this.docs).then(resolve, reject);
  }
}

class MemoryStore {
  constructor() {
    this.collections = {
      users: new MemoryCollection('users'),
      movies: new MemoryCollection('movies'),
      theatres: new MemoryCollection('theatres'),
      shows: new MemoryCollection('shows'),
      bookings: new MemoryCollection('bookings'),
      payments: new MemoryCollection('payments'),
      notifications: new MemoryCollection('notifications'),
    };
  }

  getCollection(name) {
    const key = name.toLowerCase();
    if (!this.collections[key]) {
      this.collections[key] = new MemoryCollection(key);
    }
    return this.collections[key];
  }
}

export const memoryStore = new MemoryStore();

// Model adapter factory that delegates to Mongoose if connected, else MemoryCollection
export const createModelAdapter = (collectionName, mongooseModel) => {
  return new Proxy(mongooseModel, {
    get(target, prop, receiver) {
      // If mongoose is connected to a live MongoDB (readyState === 1), use mongoose
      if (target.db && target.db.readyState === 1) {
        return Reflect.get(target, prop, receiver);
      }

      // Otherwise, use high-speed in-memory store
      const col = memoryStore.getCollection(collectionName);
      if (typeof col[prop] === 'function') {
        return col[prop].bind(col);
      }
      return col[prop];
    },
  });
};
