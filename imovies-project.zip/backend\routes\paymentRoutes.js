import express from 'express';
import {
  processPayment,
  getPaymentByTransactionId,
} from '../controllers/paymentController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/process', protect, processPayment);
router.get('/transaction/:id', protect, getPaymentByTransactionId);

export default router;
