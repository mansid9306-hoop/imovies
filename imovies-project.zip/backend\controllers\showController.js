import Show, { generateSeatLayout } from '../models/Show.js';

// Helper to auto-release expired locked seats in a show
const releaseExpiredLocks = (show) => {
  const now = new Date();
  let modified = false;

  show.seatMatrix.forEach((seat) => {
    if (seat.status === 'locked' && seat.lockExpiry && new Date(seat.lockExpiry) < now) {
      seat.status = 'available';
      seat.lockedBy = null;
      seat.lockExpiry = null;
      modified = true;
    }
  });

  if (modified) {
    show.availableSeats = show.seatMatrix.filter((s) => s.status === 'available').length;
  }

  return modified;
};

// @desc    Get shows with filtering
// @route   GET /api/shows
// @access  Public
export const getShows = async (req, res) => {
  try {
    const { movieId, theatreId, date } = req.query;
    const query = {};

    if (movieId) query.movieId = movieId;
    if (theatreId) query.theatreId = theatreId;
    if (date) query.showDate = date;

    const shows = await Show.find(query)
      .populate('movieId', 'title poster duration rating certificate genre language')
      .populate('theatreId', 'name city location address facilities')
      .sort({ showDate: 1, showTime: 1 });

    res.json({ success: true, count: shows.length, data: shows });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single show by ID with real-time seat matrix
// @route   GET /api/shows/:id
// @access  Public
export const getShowById = async (req, res) => {
  try {
    const show = await Show.findById(req.params.id)
      .populate('movieId', 'title poster duration rating certificate genre language banner trailerUrl')
      .populate('theatreId', 'name city location address facilities');

    if (!show) {
      return res.status(404).json({ success: false, message: 'Show not found' });
    }

    // Auto-clean any expired locks
    if (releaseExpiredLocks(show)) {
      await show.save();
    }

    res.json({ success: true, data: show });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new show
// @route   POST /api/shows
// @access  Private/Admin
export const createShow = async (req, res) => {
  try {
    const { movieId, theatreId, screenName, showDate, showTime, pricing } = req.body;

    const showPricing = {
      vip: pricing?.vip || 350,
      premium: pricing?.premium || 250,
      standard: pricing?.standard || 180,
    };

    const seatMatrix = generateSeatLayout(showPricing);

    const show = await Show.create({
      movieId,
      theatreId,
      screenName: screenName || 'Screen 1',
      showDate,
      showTime,
      pricing: showPricing,
      seatMatrix,
      totalSeats: seatMatrix.length,
      availableSeats: seatMatrix.length,
    });

    const populatedShow = await Show.findById(show._id)
      .populate('movieId', 'title poster duration')
      .populate('theatreId', 'name city location');

    res.status(201).json({ success: true, data: populatedShow });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Update show
// @route   PUT /api/shows/:id
// @access  Private/Admin
export const updateShow = async (req, res) => {
  try {
    const show = await Show.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!show) {
      return res.status(404).json({ success: false, message: 'Show not found' });
    }
    res.json({ success: true, data: show });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete show
// @route   DELETE /api/shows/:id
// @access  Private/Admin
export const deleteShow = async (req, res) => {
  try {
    const show = await Show.findById(req.params.id);
    if (!show) {
      return res.status(404).json({ success: false, message: 'Show not found' });
    }
    await show.deleteOne();
    res.json({ success: true, message: 'Show deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Lock seats temporarily (8 mins) during user checkout
// @route   POST /api/shows/:id/lock-seats
// @access  Private
export const lockSeats = async (req, res) => {
  try {
    const { seatIds } = req.body;
    if (!seatIds || !Array.isArray(seatIds) || seatIds.length === 0) {
      return res.status(400).json({ success: false, message: 'Please provide seat IDs to lock' });
    }

    const show = await Show.findById(req.params.id);
    if (!show) {
      return res.status(404).json({ success: false, message: 'Show not found' });
    }

    // Clean expired locks first
    releaseExpiredLocks(show);

    const lockDuration = 8 * 60 * 1000; // 8 minutes
    const lockExpiry = new Date(Date.now() + lockDuration);

    const unavailableSeats = [];
    for (const seatId of seatIds) {
      const seat = show.seatMatrix.find((s) => s.seatId === seatId);
      if (!seat) {
        return res.status(400).json({ success: false, message: `Seat ${seatId} does not exist in this auditorium` });
      }

      if (seat.status === 'booked') {
        unavailableSeats.push(`${seatId} (already booked)`);
      } else if (
        seat.status === 'locked' &&
        seat.lockedBy &&
        seat.lockedBy.toString() !== req.user._id.toString()
      ) {
        unavailableSeats.push(`${seatId} (currently selected by another customer)`);
      }
    }

    if (unavailableSeats.length > 0) {
      return res.status(409).json({
        success: false,
        message: `Seats unavailable: ${unavailableSeats.join(', ')}`,
      });
    }

    // Lock the requested seats
    show.seatMatrix.forEach((seat) => {
      if (seatIds.includes(seat.seatId)) {
        seat.status = 'locked';
        seat.lockedBy = req.user._id;
        seat.lockExpiry = lockExpiry;
      }
    });

    show.availableSeats = show.seatMatrix.filter((s) => s.status === 'available').length;
    await show.save();

    // Broadcast real-time update via Socket.io if available
    if (req.io) {
      req.io.to(`show_${show._id}`).emit('seats_updated', {
        showId: show._id,
        seatMatrix: show.seatMatrix,
        availableSeats: show.availableSeats,
      });
    }

    res.json({
      success: true,
      message: 'Seats locked successfully for checkout',
      lockExpiry,
      lockedSeats: seatIds,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Unlock seats if user aborts or changes selection
// @route   POST /api/shows/:id/unlock-seats
// @access  Private
export const unlockSeats = async (req, res) => {
  try {
    const { seatIds } = req.body;
    const show = await Show.findById(req.params.id);
    if (!show) {
      return res.status(404).json({ success: false, message: 'Show not found' });
    }

    show.seatMatrix.forEach((seat) => {
      if (
        (!seatIds || seatIds.includes(seat.seatId)) &&
        seat.status === 'locked' &&
        seat.lockedBy &&
        seat.lockedBy.toString() === req.user._id.toString()
      ) {
        seat.status = 'available';
        seat.lockedBy = null;
        seat.lockExpiry = null;
      }
    });

    show.availableSeats = show.seatMatrix.filter((s) => s.status === 'available').length;
    await show.save();

    // Broadcast update
    if (req.io) {
      req.io.to(`show_${show._id}`).emit('seats_updated', {
        showId: show._id,
        seatMatrix: show.seatMatrix,
        availableSeats: show.availableSeats,
      });
    }

    res.json({ success: true, message: 'Seats unlocked' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
