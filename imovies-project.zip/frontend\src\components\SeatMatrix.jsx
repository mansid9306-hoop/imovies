import React from 'react';

const SeatMatrix = ({
  seatMatrix = [],
  selectedSeats = [],
  onSeatToggle,
  pricing = { vip: 350, premium: 250, standard: 180 },
  maxSeats = 8,
}) => {
  // Group seats by tier or row
  const rows = ['A', 'B', 'C', 'D', 'E', 'F'];

  const getTierBadge = (tier) => {
    switch (tier) {
      case 'vip':
        return { name: 'VIP Recliners', price: pricing.vip, badgeClass: 'badge-gold' };
      case 'premium':
        return { name: 'Premium Club', price: pricing.premium, badgeClass: 'badge-blue' };
      default:
        return { name: 'Standard Classic', price: pricing.standard, badgeClass: 'badge-red' };
    }
  };

  const getSeatStatus = (seat) => {
    if (selectedSeats.includes(seat.seatId)) return 'selected';
    return seat.status; // 'available', 'booked', 'locked'
  };

  return (
    <div className="seat-matrix-container w-100 py-3">
      {/* Curved Cinema Screen */}
      <div className="mb-5 mx-auto" style={{ maxWidth: '640px' }}>
        <div className="screen-curve mb-2"></div>
        <p className="text-center text-secondary small text-uppercase mb-0" style={{ letterSpacing: '4px', fontSize: '10px' }}>
          All Eyes This Way • Cinema Screen
        </p>
      </div>

      {/* Seat Rows Container */}
      <div className="d-flex flex-column gap-3 align-items-center mb-5 overflow-auto pb-2">
        {/* VIP Section */}
        <div className="w-100 text-center mb-1">
          <div className="d-inline-flex align-items-center gap-2 mb-2">
            <span className="badge badge-gold">VIP Recliners</span>
            <span className="text-white small fw-bold">₹{pricing.vip}</span>
          </div>
          <div className="d-flex flex-column gap-2 align-items-center">
            {['A', 'B'].map((rowLetter) => (
              <div key={rowLetter} className="d-flex align-items-center gap-2">
                <span className="text-secondary fw-bold small" style={{ width: '20px' }}>
                  {rowLetter}
                </span>
                <div className="d-flex gap-1 gap-sm-2">
                  {seatMatrix
                    .filter((s) => s.row === rowLetter)
                    .map((seat) => {
                      const status = getSeatStatus(seat);
                      return (
                        <button
                          key={seat.seatId}
                          type="button"
                          className={`seat-btn ${status}`}
                          disabled={status === 'booked' || status === 'locked'}
                          onClick={() => onSeatToggle(seat)}
                          title={`${seat.seatId} - ₹${seat.price} (${status})`}
                        >
                          {seat.col}
                        </button>
                      );
                    })}
                </div>
                <span className="text-secondary fw-bold small" style={{ width: '20px' }}>
                  {rowLetter}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Premium Section */}
        <div className="w-100 text-center my-2">
          <div className="d-inline-flex align-items-center gap-2 mb-2">
            <span className="badge badge-blue">Premium Club</span>
            <span className="text-white small fw-bold">₹{pricing.premium}</span>
          </div>
          <div className="d-flex flex-column gap-2 align-items-center">
            {['C', 'D'].map((rowLetter) => (
              <div key={rowLetter} className="d-flex align-items-center gap-2">
                <span className="text-secondary fw-bold small" style={{ width: '20px' }}>
                  {rowLetter}
                </span>
                <div className="d-flex gap-1 gap-sm-2">
                  {seatMatrix
                    .filter((s) => s.row === rowLetter)
                    .map((seat) => {
                      const status = getSeatStatus(seat);
                      return (
                        <button
                          key={seat.seatId}
                          type="button"
                          className={`seat-btn ${status}`}
                          disabled={status === 'booked' || status === 'locked'}
                          onClick={() => onSeatToggle(seat)}
                          title={`${seat.seatId} - ₹${seat.price} (${status})`}
                        >
                          {seat.col}
                        </button>
                      );
                    })}
                </div>
                <span className="text-secondary fw-bold small" style={{ width: '20px' }}>
                  {rowLetter}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Standard Section */}
        <div className="w-100 text-center mt-1">
          <div className="d-inline-flex align-items-center gap-2 mb-2">
            <span className="badge badge-red">Standard Classic</span>
            <span className="text-white small fw-bold">₹{pricing.standard}</span>
          </div>
          <div className="d-flex flex-column gap-2 align-items-center">
            {['E', 'F'].map((rowLetter) => (
              <div key={rowLetter} className="d-flex align-items-center gap-2">
                <span className="text-secondary fw-bold small" style={{ width: '20px' }}>
                  {rowLetter}
                </span>
                <div className="d-flex gap-1 gap-sm-2">
                  {seatMatrix
                    .filter((s) => s.row === rowLetter)
                    .map((seat) => {
                      const status = getSeatStatus(seat);
                      return (
                        <button
                          key={seat.seatId}
                          type="button"
                          className={`seat-btn ${status}`}
                          disabled={status === 'booked' || status === 'locked'}
                          onClick={() => onSeatToggle(seat)}
                          title={`${seat.seatId} - ₹${seat.price} (${status})`}
                        >
                          {seat.col}
                        </button>
                      );
                    })}
                </div>
                <span className="text-secondary fw-bold small" style={{ width: '20px' }}>
                  {rowLetter}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="d-flex flex-wrap justify-content-center align-items-center gap-4 py-3 border-top border-secondary border-opacity-25">
        <div className="d-flex align-items-center gap-2">
          <div className="seat-btn available" style={{ cursor: 'default' }}></div>
          <span className="text-secondary small">Available</span>
        </div>
        <div className="d-flex align-items-center gap-2">
          <div className="seat-btn selected" style={{ cursor: 'default' }}></div>
          <span className="text-secondary small">Selected</span>
        </div>
        <div className="d-flex align-items-center gap-2">
          <div className="seat-btn booked" style={{ cursor: 'default' }}></div>
          <span className="text-secondary small">Sold Out</span>
        </div>
        <div className="d-flex align-items-center gap-2">
          <div className="seat-btn locked" style={{ cursor: 'default' }}></div>
          <span className="text-secondary small">Reserved / In Checkout</span>
        </div>
      </div>
    </div>
  );
};

export default SeatMatrix;
