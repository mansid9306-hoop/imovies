import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { MapPin, Compass, Film, Tv, ShieldCheck, Ticket } from 'lucide-react';

const TheatresPage = ({ selectedCity }) => {
  const [theatres, setTheatres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cityFilter, setCityFilter] = useState(selectedCity === 'All Cities' ? 'all' : selectedCity);

  useEffect(() => {
    if (selectedCity && selectedCity !== 'All Cities') {
      setCityFilter(selectedCity);
    }
  }, [selectedCity]);

  useEffect(() => {
    const fetchTheatres = async () => {
      try {
        setLoading(true);
        const params = {};
        if (cityFilter !== 'all') params.city = cityFilter;

        const res = await api.get('/theatres', { params });
        if (res.data.success) {
          setTheatres(res.data.data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchTheatres();
  }, [cityFilter]);

  const cities = ['all', 'Mumbai', 'Bengaluru', 'Delhi NCR', 'Hyderabad'];

  return (
    <div className="container py-4">
      {/* Header */}
      <div className="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-4 pb-3 border-bottom border-secondary border-opacity-25">
        <div>
          <h2 className="fw-black text-white mb-1">Cinema Theatres & Complexes</h2>
          <p className="text-secondary small mb-0">
            Find premium theatres equipped with IMAX, Dolby Atmos, and 4DX seating
          </p>
        </div>

        {/* City Filter Pills */}
        <div className="d-flex flex-wrap gap-2">
          {cities.map((c) => (
            <button
              key={c}
              className={`btn btn-sm rounded-pill px-3 py-1.5 transition ${
                cityFilter === c ? 'glow-btn' : 'btn-outline-secondary text-light'
              }`}
              onClick={() => setCityFilter(c)}
            >
              {c === 'all' ? 'All Cities' : c}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-danger" role="status"></div>
        </div>
      ) : theatres.length === 0 ? (
        <div className="cinema-card p-5 text-center my-4">
          <Compass size={48} className="text-secondary mb-3" />
          <h5 className="text-white">No Theatres Found in this City</h5>
          <p className="text-secondary small">Try selecting "All Cities" or check back soon.</p>
        </div>
      ) : (
        <div className="row g-4 mb-5">
          {theatres.map((theatre) => (
            <div key={theatre._id} className="col-12 col-lg-6">
              <div className="cinema-card p-4 h-100 d-flex flex-column">
                <div className="d-flex justify-content-between align-items-start mb-2">
                  <div>
                    <h5 className="text-white fw-bold mb-1">{theatre.name}</h5>
                    <div className="text-secondary small d-flex align-items-center gap-1 mb-2">
                      <MapPin size={14} className="text-danger flex-shrink-0" />
                      <span>{theatre.location}, {theatre.city}</span>
                    </div>
                  </div>
                  <span className="badge badge-gold">{theatre.city}</span>
                </div>

                <p className="text-secondary small mb-3">{theatre.address}</p>

                {/* Screens */}
                <div className="mb-3">
                  <label className="text-secondary small d-block mb-1">Available Screens & Formats:</label>
                  <div className="d-flex flex-wrap gap-2">
                    {theatre.screens?.map((sc, idx) => (
                      <span key={idx} className="badge badge-blue">
                        <Tv size={12} className="me-1" /> {sc.name}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Facilities */}
                <div className="mb-4">
                  <label className="text-secondary small d-block mb-1">Amenities:</label>
                  <div className="d-flex flex-wrap gap-1">
                    {theatre.facilities?.map((f, idx) => (
                      <span
                        key={idx}
                        className="badge"
                        style={{
                          background: 'rgba(255, 255, 255, 0.05)',
                          color: '#94a3b8',
                          fontSize: '11px',
                        }}
                      >
                        {f}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action button */}
                <div className="mt-auto pt-3 border-top border-secondary border-opacity-25 d-flex justify-content-between align-items-center">
                  <span className="text-secondary small">
                    {theatre.screens?.length || 1} Auditorium Screens
                  </span>
                  <Link
                    to="/movies"
                    className="btn glow-btn btn-sm d-flex align-items-center gap-1 px-3 py-1.5"
                  >
                    <Ticket size={14} /> View Shows & Book
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TheatresPage;
