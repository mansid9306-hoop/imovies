import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Film, Lock, Mail, AlertCircle, ArrowRight, UserCheck, Shield } from 'lucide-react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = location.state?.from?.pathname || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    const res = await login(email, password);
    setSubmitting(false);

    if (res.success) {
      navigate(from, { replace: true });
    } else {
      setError(res.message);
    }
  };

  const handleQuickLogin = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setError('');
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-12 col-md-6 col-lg-5">
          <div className="cinema-card p-4 p-md-5">
            {/* Logo & Heading */}
            <div className="text-center mb-4">
              <div
                className="d-inline-flex align-items-center justify-content-center mb-2"
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 12,
                  background: 'linear-gradient(135deg, #e50914 0%, #b80710 100%)',
                  boxShadow: '0 0 20px rgba(229, 9, 20, 0.4)',
                }}
              >
                <Film color="#ffffff" size={28} />
              </div>
              <h3 className="fw-black text-white mb-1">Welcome Back</h3>
              <p className="text-secondary small">
                Sign in to your IMovies account to reserve cinema tickets
              </p>
            </div>

            {error && (
              <div className="alert alert-danger d-flex align-items-center gap-2 mb-3" role="alert">
                <AlertCircle size={16} />
                <span className="small">{error}</span>
              </div>
            )}

            {/* Quick Demo Credentials Box for Evaluation */}
            <div className="p-3 mb-4 rounded-3 bg-dark bg-opacity-75 border border-secondary border-opacity-25">
              <span className="text-secondary small d-block mb-2 fw-semibold">
                Quick 1-Click Evaluation Credentials:
              </span>
              <div className="d-flex gap-2">
                <button
                  type="button"
                  className="btn btn-sm btn-outline-warning w-50 d-flex align-items-center justify-content-center gap-1"
                  onClick={() => handleQuickLogin('alex@example.com', 'password123')}
                >
                  <UserCheck size={14} /> Demo User
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-outline-danger w-50 d-flex align-items-center justify-content-center gap-1"
                  onClick={() => handleQuickLogin('admin@imovies.com', 'admin123')}
                >
                  <Shield size={14} /> Cinema Admin
                </button>
              </div>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="text-secondary small mb-1">Email Address</label>
                <div className="position-relative">
                  <Mail
                    size={16}
                    className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                  />
                  <input
                    type="email"
                    className="form-control cinema-input ps-5"
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="mb-4">
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <label className="text-secondary small mb-0">Password</label>
                </div>
                <div className="position-relative">
                  <Lock
                    size={16}
                    className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                  />
                  <input
                    type="password"
                    className="form-control cinema-input ps-5"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="btn glow-btn w-100 py-2.5 rounded-3 mb-3 d-flex align-items-center justify-content-center gap-2"
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <div className="spinner-border spinner-border-sm" role="status"></div>
                    <span>Signing in...</span>
                  </>
                ) : (
                  <>
                    <span>Sign In</span>
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>

            <div className="text-center mt-3 pt-3 border-top border-secondary border-opacity-25">
              <span className="text-secondary small">
                Don't have an account yet?{' '}
                <Link to="/register" className="text-danger fw-bold text-decoration-none">
                  Sign Up
                </Link>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
