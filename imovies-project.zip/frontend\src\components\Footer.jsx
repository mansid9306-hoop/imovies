import React from 'react';
import { Film, ExternalLink, Heart, Shield, Code2 } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="mt-auto py-5 border-top border-secondary border-opacity-25" style={{ background: '#090d16' }}>
      <div className="container">
        <div className="row g-4 mb-4">
          {/* Brand Info */}
          <div className="col-12 col-md-5">
            <div className="d-flex align-items-center mb-3">
              <div
                className="d-flex align-items-center justify-content-center me-2"
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 8,
                  background: 'linear-gradient(135deg, #e50914 0%, #b80710 100%)',
                }}
              >
                <Film color="#ffffff" size={20} />
              </div>
              <span className="fs-4 fw-black text-white">
                I<span style={{ color: '#e50914' }}>MOVIES</span>
              </span>
            </div>
            <p className="text-secondary small pe-lg-4">
              IMovies is a seamless online platform that enhances the cinema experience by allowing users to browse movies,
              select showtimes, and reserve seats with real-time availability tracking. Built on the MERN stack.
            </p>
            <div className="d-flex gap-2 mt-3">
              <span className="badge bg-dark border border-secondary border-opacity-50 text-secondary">MongoDB</span>
              <span className="badge bg-dark border border-secondary border-opacity-50 text-secondary">Express.js</span>
              <span className="badge bg-dark border border-secondary border-opacity-50 text-secondary">React.js</span>
              <span className="badge bg-dark border border-secondary border-opacity-50 text-secondary">Node.js</span>
              <span className="badge bg-dark border border-secondary border-opacity-50 text-secondary">Socket.io</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-6 col-md-2">
            <h6 className="text-white fw-bold mb-3 small text-uppercase letter-spacing-1">Quick Links</h6>
            <ul className="list-unstyled text-secondary small d-flex flex-column gap-2 mb-0">
              <li><a href="/movies" className="text-secondary text-decoration-none hover-white">Now Showing</a></li>
              <li><a href="/movies?status=upcoming" className="text-secondary text-decoration-none hover-white">Upcoming</a></li>
              <li><a href="/theatres" className="text-secondary text-decoration-none hover-white">Cinemas & Theatres</a></li>
              <li><a href="/my-bookings" className="text-secondary text-decoration-none hover-white">My Bookings</a></li>
            </ul>
          </div>

          {/* Cinema Formats */}
          <div className="col-6 col-md-2">
            <h6 className="text-white fw-bold mb-3 small text-uppercase letter-spacing-1">Experiences</h6>
            <ul className="list-unstyled text-secondary small d-flex flex-column gap-2 mb-0">
              <li><span className="hover-white">IMAX 3D Laser</span></li>
              <li><span className="hover-white">Dolby Atmos 7.1</span></li>
              <li><span className="hover-white">4DX Motion Seats</span></li>
              <li><span className="hover-white">Director's Cut Lounge</span></li>
            </ul>
          </div>

          {/* Project Review Links for Mentor */}
          <div className="col-12 col-md-3">
            <h6 className="text-white fw-bold mb-3 small text-uppercase letter-spacing-1">Evaluation & Links</h6>
            <p className="text-secondary small mb-3">
              Ready for mentor review. Connect GitHub and live deployment links below.
            </p>
            <div className="d-flex flex-column gap-2">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="btn btn-sm btn-outline-secondary d-flex align-items-center justify-content-center gap-2 text-light"
              >
                <i className="bi bi-github me-1"></i> GitHub Repository
              </a>
              <div className="d-flex align-items-center gap-2 text-secondary small mt-1">
                <Shield size={14} className="text-success" />
                <span>JWT Authentication & Socket.io Enabled</span>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-4 border-top border-secondary border-opacity-10 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
          <span className="text-secondary small">
            © {new Date().getFullYear()} IMovies Entertainment Inc. Movie ticket booking made simple.
          </span>
          <span className="text-secondary small d-flex align-items-center gap-1">
            Engineered with <Heart size={14} className="text-danger fill-danger" /> for Cinema Lovers
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
