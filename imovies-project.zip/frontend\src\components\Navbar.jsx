import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Film,
  Compass,
  Ticket,
  ShieldCheck,
  Bell,
  User as UserIcon,
  LogOut,
  ChevronDown,
  MapPin,
  Menu,
  X,
} from 'lucide-react';

const Navbar = ({ selectedCity, setSelectedCity }) => {
  const { user, logout, notifications, markNotificationRead, isAdmin } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const cities = ['All Cities', 'Mumbai', 'Bengaluru', 'Delhi NCR', 'Hyderabad'];

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="cinema-navbar py-2 px-3 px-md-4">
      <div className="container-fluid d-flex align-items-center justify-content-between">
        {/* Brand Logo */}
        <Link to="/" className="d-flex align-items-center text-decoration-none me-3">
          <div
            className="d-flex align-items-center justify-content-center me-2"
            style={{
              width: 40,
              height: 40,
              borderRadius: 10,
              background: 'linear-gradient(135deg, #e50914 0%, #b80710 100%)',
              boxShadow: '0 0 16px rgba(229, 9, 20, 0.5)',
            }}
          >
            <Film color="#ffffff" size={24} />
          </div>
          <div>
            <span className="fs-4 fw-black text-white letter-spacing-1">
              I<span style={{ color: '#e50914' }}>MOVIES</span>
            </span>
            <span
              className="d-none d-sm-block text-secondary"
              style={{ fontSize: '10px', marginTop: '-4px', letterSpacing: '1px' }}
            >
              CINEMA TICKETING
            </span>
          </div>
        </Link>

        {/* City Selector */}
        <div className="d-none d-md-flex align-items-center me-auto ms-3">
          <MapPin size={16} className="text-danger me-1" />
          <select
            className="form-select form-select-sm cinema-input text-white border-0 py-1"
            style={{ width: '135px', cursor: 'pointer', backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
          >
            {cities.map((city) => (
              <option key={city} value={city} style={{ background: '#0f172a' }}>
                {city}
              </option>
            ))}
          </select>
        </div>

        {/* Desktop Nav Links */}
        <div className="d-none d-lg-flex align-items-center gap-3 me-3">
          <Link
            to="/movies"
            className={`text-decoration-none px-3 py-1 rounded-pill transition ${
              isActive('/movies')
                ? 'text-white fw-bold bg-danger bg-opacity-25'
                : 'text-secondary hover-white'
            }`}
          >
            <Film size={16} className="me-1" /> Movies
          </Link>
          <Link
            to="/theatres"
            className={`text-decoration-none px-3 py-1 rounded-pill transition ${
              isActive('/theatres')
                ? 'text-white fw-bold bg-danger bg-opacity-25'
                : 'text-secondary hover-white'
            }`}
          >
            <Compass size={16} className="me-1" /> Theatres
          </Link>

          {user && (
            <Link
              to="/my-bookings"
              className={`text-decoration-none px-3 py-1 rounded-pill transition ${
                isActive('/my-bookings')
                  ? 'text-white fw-bold bg-danger bg-opacity-25'
                  : 'text-secondary hover-white'
              }`}
            >
              <Ticket size={16} className="me-1" /> My Bookings
            </Link>
          )}

          {isAdmin && (
            <Link
              to="/admin"
              className={`text-decoration-none px-3 py-1 rounded-pill transition ${
                isActive('/admin')
                  ? 'text-white fw-bold bg-warning bg-opacity-25'
                  : 'text-warning hover-gold'
              }`}
            >
              <ShieldCheck size={16} className="me-1" /> Admin Portal
            </Link>
          )}
        </div>

        {/* Right Action Icons & User Dropdown */}
        <div className="d-flex align-items-center gap-2">
          {user ? (
            <>
              {/* Notification Bell */}
              <div className="position-relative me-2">
                <button
                  className="btn btn-sm text-secondary p-2 rounded-circle position-relative hover-white"
                  style={{ background: 'rgba(255, 255, 255, 0.05)' }}
                  onClick={() => setShowNotifications(!showNotifications)}
                  title="Notifications"
                >
                  <Bell size={18} />
                  {unreadCount > 0 && (
                    <span
                      className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                      style={{ fontSize: '10px' }}
                    >
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown Popup */}
                {showNotifications && (
                  <div
                    className="position-absolute end-0 mt-2 cinema-card p-3 shadow-lg"
                    style={{ width: '320px', zIndex: 1050, background: '#1e293b' }}
                  >
                    <div className="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom border-secondary border-opacity-25">
                      <h6 className="mb-0 text-white fw-bold">Notifications</h6>
                      <span className="badge badge-gold">{unreadCount} new</span>
                    </div>

                    <div style={{ maxHeight: '250px', overflowY: 'auto' }}>
                      {notifications.length === 0 ? (
                        <p className="text-secondary small mb-0 text-center py-3">
                          No notifications right now
                        </p>
                      ) : (
                        notifications.slice(0, 5).map((n) => (
                          <div
                            key={n._id}
                            className={`p-2 mb-2 rounded ${
                              n.read ? 'bg-dark bg-opacity-25' : 'bg-dark bg-opacity-75 border-start border-3 border-danger'
                            }`}
                            onClick={() => markNotificationRead(n._id)}
                            style={{ cursor: 'pointer' }}
                          >
                            <div className="d-flex justify-content-between">
                              <strong className="text-white small">{n.title}</strong>
                              <span className="text-secondary" style={{ fontSize: '10px' }}>
                                {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-secondary small mb-0 mt-1" style={{ fontSize: '12px' }}>
                              {n.message}
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* User Avatar & Name */}
              <div className="dropdown">
                <button
                  className="btn btn-sm d-flex align-items-center gap-2 p-1 pe-2 rounded-pill cinema-card text-white border-0"
                  type="button"
                  data-bs-toggle="dropdown"
                  style={{ background: 'rgba(255, 255, 255, 0.08)' }}
                >
                  <img
                    src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                    alt={user.name}
                    className="rounded-circle"
                    style={{ width: 28, height: 28, objectFit: 'cover' }}
                  />
                  <span className="small fw-semibold d-none d-sm-inline">{user.name.split(' ')[0]}</span>
                  <ChevronDown size={14} className="text-secondary" />
                </button>
                <ul
                  className="dropdown-menu dropdown-menu-end shadow-lg py-2 mt-2"
                  style={{ background: '#1e293b', border: '1px solid rgba(255,255,255,0.1)' }}
                >
                  <li className="px-3 py-1 border-bottom border-secondary border-opacity-25 mb-1">
                    <span className="small text-white fw-bold d-block">{user.name}</span>
                    <span className="text-secondary d-block" style={{ fontSize: '11px' }}>
                      {user.email}
                    </span>
                    <span className="badge badge-gold mt-1 text-uppercase" style={{ fontSize: '9px' }}>
                      {user.role}
                    </span>
                  </li>
                  <li>
                    <Link className="dropdown-item text-light small py-2 d-flex align-items-center gap-2" to="/profile">
                      <UserIcon size={14} /> My Profile
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item text-light small py-2 d-flex align-items-center gap-2" to="/my-bookings">
                      <Ticket size={14} /> My Bookings
                    </Link>
                  </li>
                  {isAdmin && (
                    <li>
                      <Link className="dropdown-item text-warning small py-2 d-flex align-items-center gap-2" to="/admin">
                        <ShieldCheck size={14} /> Admin Portal
                      </Link>
                    </li>
                  )}
                  <li>
                    <hr className="dropdown-divider border-secondary border-opacity-25" />
                  </li>
                  <li>
                    <button
                      className="dropdown-item text-danger small py-2 d-flex align-items-center gap-2"
                      onClick={handleLogout}
                    >
                      <LogOut size={14} /> Sign Out
                    </button>
                  </li>
                </ul>
              </div>
            </>
          ) : (
            <div className="d-flex align-items-center gap-2">
              <Link to="/login" className="btn btn-sm btn-outline-light px-3 py-1 rounded-pill">
                Sign In
              </Link>
              <Link to="/register" className="btn btn-sm glow-btn px-3 py-1 rounded-pill d-none d-sm-inline">
                Sign Up
              </Link>
            </div>
          )}

          {/* Mobile Menu Toggle Button */}
          <button
            className="btn btn-sm text-white p-2 d-lg-none"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="d-lg-none p-3 mt-2 cinema-card bg-dark border border-secondary border-opacity-25 rounded-3">
          <div className="d-flex flex-column gap-2">
            <div className="mb-2">
              <label className="text-secondary small mb-1">Select City:</label>
              <select
                className="form-select form-select-sm cinema-input text-white"
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
              >
                {cities.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </div>

            <Link
              to="/movies"
              className="text-white text-decoration-none py-2 px-2 rounded hover-card"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Film size={16} className="me-2 text-danger" /> Browse Movies
            </Link>
            <Link
              to="/theatres"
              className="text-white text-decoration-none py-2 px-2 rounded hover-card"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Compass size={16} className="me-2 text-primary" /> Cinema Theatres
            </Link>
            {user && (
              <Link
                to="/my-bookings"
                className="text-white text-decoration-none py-2 px-2 rounded hover-card"
                onClick={() => setMobileMenuOpen(false)}
              >
                <Ticket size={16} className="me-2 text-warning" /> My Bookings
              </Link>
            )}
            {isAdmin && (
              <Link
                to="/admin"
                className="text-warning text-decoration-none py-2 px-2 rounded hover-card"
                onClick={() => setMobileMenuOpen(false)}
              >
                <ShieldCheck size={16} className="me-2 text-warning" /> Admin Portal
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
