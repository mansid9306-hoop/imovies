import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import {
  Star,
  Clock,
  Calendar,
  Film,
  Play,
  MapPin,
  ChevronRight,
  Shield,
  UserCheck,
  Check,
} from 'lucide-react';

const MovieDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState('');
  const [showTrailerModal, setShowTrailerModal] = useState(false);

  useEffect(() => {
    const fetchMovieDetails = async () => {
      try {
        setLoading(true);
        const res = await api.get(`/movies/${id}`);
        if (res.data.success) {
          setMovie(res.data.data);

          // Get unique show dates if shows exist
          if (res.data.data.shows && res.data.data.shows.length > 0) {
            const dates = [...new Set(res.data.data.shows.map((s) => s.showDate))].sort();
            setSelectedDate(dates[0]);
          }
        }
      } catch (err) {
        console.error('Failed to load movie details', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMovieDetails();
  }, [id]);

  if (loading) {
    return (
      <div className="d-flex align-items-center justify-content-center min-vh-50 py-5">
        <div className="spinner-border text-danger" role="status"></div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="container py-5 text-center">
        <h4 className="text-white">Movie not found</h4>
        <Link to="/movies" className="btn btn-sm glow-btn mt-3">
          Back to Movies
        </Link>
      </div>
    );
  }

  // Filter shows by selected date
  const filteredShows = (movie.shows || []).filter((s) => s.showDate === selectedDate);

  // Group shows by theatre
  const showsByTheatre = filteredShows.reduce((acc, show) => {
    const theatreId = show.theatreId?._id || show.theatreId;
    const theatreName = show.theatreId?.name || 'Grand Cinema';
    const theatreLocation = show.theatreId?.location || '';
    const theatreCity = show.theatreId?.city || '';
    const facilities = show.theatreId?.facilities || [];

    if (!acc[theatreId]) {
      acc[theatreId] = {
        name: theatreName,
        location: theatreLocation,
        city: theatreCity,
        facilities,
        shows: [],
      };
    }
    acc[theatreId].shows.push(show);
    return acc;
  }, {});

  // Distinct dates available in shows
  const availableDates = [...new Set((movie.shows || []).map((s) => s.showDate))].sort();

  return (
    <div>
      {/* Hero Backdrop Banner */}
      <div
        className="position-relative py-5"
        style={{
          minHeight: '440px',
          backgroundImage: `url(${movie.banner || movie.poster})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center 30%',
        }}
      >
        <div className="hero-overlay"></div>
        <div className="container position-relative" style={{ zIndex: 2 }}>
          <div className="row g-4 align-items-center">
            {/* Poster Card */}
            <div className="col-12 col-md-4 col-lg-3 text-center text-md-start">
              <img
                src={movie.poster}
                alt={movie.title}
                className="rounded-4 shadow-2xl w-100 object-fit-cover"
                style={{ maxHeight: '420px', maxWidth: '300px', border: '2px solid rgba(255,255,255,0.1)' }}
              />
            </div>

            {/* Movie Info */}
            <div className="col-12 col-md-8 col-lg-9 text-white">
              <div className="d-flex flex-wrap align-items-center gap-2 mb-2">
                <span className="badge badge-red">{movie.certificate || 'UA'}</span>
                <span className="badge badge-gold d-flex align-items-center gap-1">
                  <Star size={13} className="fill-warning" /> {movie.rating ? movie.rating.toFixed(1) : '8.0'}/10 ({movie.votesCount} votes)
                </span>
                <span className="badge badge-blue">
                  {movie.status === 'now_showing' ? 'NOW SHOWING' : 'UPCOMING'}
                </span>
              </div>

              <h1 className="display-5 fw-black text-white mb-2">{movie.title}</h1>

              <div className="d-flex flex-wrap align-items-center gap-3 text-secondary mb-3 small">
                <span className="d-flex align-items-center gap-1 text-light">
                  <Clock size={15} /> {Math.floor(movie.duration / 60)}h {movie.duration % 60}m
                </span>
                <span>•</span>
                <span className="text-light">{movie.genre?.join(', ')}</span>
                <span>•</span>
                <span className="text-light">{movie.language?.join(', ')}</span>
                <span>•</span>
                <span>Released: {new Date(movie.releaseDate).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              </div>

              <p className="text-light text-opacity-85 mb-4" style={{ maxWidth: '780px', lineHeight: 1.6 }}>
                {movie.description}
              </p>

              <div className="d-flex flex-wrap gap-3">
                {movie.trailerUrl && (
                  <button
                    className="btn btn-outline-light px-4 py-2 rounded-pill d-flex align-items-center gap-2"
                    onClick={() => setShowTrailerModal(true)}
                  >
                    <Play size={16} className="fill-white" /> Watch Official Trailer
                  </button>
                )}
                <a href="#showtimes" className="btn glow-btn px-4 py-2 rounded-pill d-flex align-items-center gap-2">
                  Book Seats <ChevronRight size={16} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-5">
        {/* Cast & Crew Section */}
        {movie.cast && movie.cast.length > 0 && (
          <div className="mb-5">
            <h4 className="fw-bold text-white mb-3">Starring Cast</h4>
            <div className="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-6 g-3">
              {movie.cast.map((actor, idx) => (
                <div key={idx} className="col text-center">
                  <div className="cinema-card p-3 h-100">
                    <img
                      src={actor.photo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'}
                      alt={actor.name}
                      className="rounded-circle mb-2 mx-auto"
                      style={{ width: '70px', height: '70px', objectFit: 'cover' }}
                    />
                    <h6 className="text-white small fw-bold mb-0 text-truncate">{actor.name}</h6>
                    <span className="text-secondary" style={{ fontSize: '11px' }}>
                      {actor.role}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Showtimes & Booking Section */}
        <div id="showtimes" className="cinema-card p-4 p-md-5">
          <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary border-opacity-25">
            <div>
              <h3 className="fw-black text-white mb-1">Select Showtime & Theatre</h3>
              <p className="text-secondary small mb-0">Choose your preferred cinema date and screening schedule</p>
            </div>

            {/* Date Selector Pills */}
            <div className="d-flex flex-wrap gap-2">
              {availableDates.length > 0 ? (
                availableDates.map((dateStr) => {
                  const dateObj = new Date(dateStr);
                  const dayName = dateObj.toLocaleDateString([], { weekday: 'short' });
                  const dayNum = dateObj.toLocaleDateString([], { day: 'numeric', month: 'short' });

                  return (
                    <button
                      key={dateStr}
                      type="button"
                      className={`btn btn-sm rounded-3 px-3 py-2 text-center transition ${
                        selectedDate === dateStr
                          ? 'glow-btn'
                          : 'btn-outline-secondary text-light'
                      }`}
                      onClick={() => setSelectedDate(dateStr)}
                    >
                      <span className="d-block text-uppercase fw-bold" style={{ fontSize: '11px' }}>
                        {dayName}
                      </span>
                      <span className="d-block fw-black" style={{ fontSize: '14px' }}>
                        {dayNum}
                      </span>
                    </button>
                  );
                })
              ) : (
                <span className="text-secondary small">No upcoming show schedules published yet</span>
              )}
            </div>
          </div>

          {/* Shows Grouped by Theatre */}
          {Object.keys(showsByTheatre).length === 0 ? (
            <div className="text-center py-5">
              <Film size={40} className="text-secondary mb-2" />
              <h5 className="text-white">No Shows Available For Selected Date</h5>
              <p className="text-secondary small">Please pick another date above or check back shortly.</p>
            </div>
          ) : (
            <div className="d-flex flex-column gap-4">
              {Object.entries(showsByTheatre).map(([theatreId, item]) => (
                <div
                  key={theatreId}
                  className="p-3 p-md-4 rounded-3"
                  style={{ background: 'rgba(15, 23, 42, 0.6)', border: '1px solid rgba(255,255,255,0.08)' }}
                >
                  <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-3">
                    <div>
                      <div className="d-flex align-items-center gap-2">
                        <MapPin size={18} className="text-danger flex-shrink-0" />
                        <h5 className="text-white fw-bold mb-0">{item.name}</h5>
                      </div>
                      <span className="text-secondary small ms-4">
                        {item.location}, {item.city}
                      </span>
                    </div>

                    <div className="d-flex flex-wrap gap-1 ms-4 ms-md-0">
                      {item.facilities?.slice(0, 3).map((f) => (
                        <span key={f} className="badge bg-dark border border-secondary border-opacity-25 text-secondary" style={{ fontSize: '10px' }}>
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Show Timing Buttons */}
                  <div className="d-flex flex-wrap gap-3 ms-md-4 mt-2">
                    {item.shows.map((show) => (
                      <button
                        key={show._id}
                        type="button"
                        className="btn btn-outline-danger p-2 px-3 rounded-3 text-start position-relative hover-card"
                        style={{ minWidth: '130px', borderColor: 'rgba(229, 9, 20, 0.4)' }}
                        onClick={() => navigate(`/booking/${show._id}`)}
                      >
                        <div className="d-flex align-items-center justify-content-between">
                          <span className="fw-bold text-white fs-6">{show.showTime}</span>
                        </div>
                        <div className="d-flex align-items-center justify-content-between gap-2 mt-1">
                          <span className="text-secondary" style={{ fontSize: '11px' }}>
                            {show.screenName || 'Screen 1'}
                          </span>
                          <span className="badge badge-gold" style={{ fontSize: '10px' }}>
                            ₹{show.pricing?.standard || 200}+
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Trailer Modal */}
      {showTrailerModal && (
        <div
          className="modal fade show d-block"
          tabIndex="-1"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.85)', backdropFilter: 'blur(8px)', zIndex: 1070 }}
        >
          <div className="modal-dialog modal-dialog-centered modal-xl">
            <div className="modal-content cinema-modal border-0 overflow-hidden">
              <div className="modal-header border-bottom border-secondary border-opacity-25 px-4 py-3">
                <h5 className="modal-title text-white fw-bold">{movie.title} - Official Trailer</h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={() => setShowTrailerModal(false)}
                ></button>
              </div>
              <div className="modal-body p-0" style={{ height: '550px' }}>
                <iframe
                  src={movie.trailerUrl}
                  title="Movie Trailer"
                  className="w-100 h-100 border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MovieDetailsPage;
