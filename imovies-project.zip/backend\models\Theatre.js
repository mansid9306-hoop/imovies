import mongoose from 'mongoose';

const screenSchema = new mongoose.Schema(
  {
    screenNumber: { type: Number, required: true },
    name: { type: String, required: true }, // e.g. "Screen 1 (IMAX Laser)", "Screen 2 (Dolby Atmos)"
    seatingCapacity: { type: Number, default: 60 },
    tierPricing: {
      vip: { type: Number, default: 350 },
      premium: { type: Number, default: 250 },
      standard: { type: Number, default: 180 },
    },
  },
  { _id: false }
);

const theatreSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Theatre name is required'],
      trim: true,
    },
    city: {
      type: String,
      required: [true, 'City is required'],
      index: true,
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Location / Area is required'],
      trim: true,
    },
    address: {
      type: String,
      default: '',
    },
    screens: [screenSchema],
    facilities: {
      type: [String],
      default: ['Dolby Atmos 7.1', '4K Laser Projection', 'Recliner Seating', 'Gourmet Cafeteria', 'Valet Parking'],
    },
  },
  {
    timestamps: true,
  }
);

theatreSchema.index({ name: 1, city: 1 });

const Theatre = mongoose.model('Theatre', theatreSchema);
import { createModelAdapter } from '../utils/memoryStore.js';
export default createModelAdapter('theatres', Theatre);
