import express from 'express';
import {
  getShows,
  getShowById,
  createShow,
  updateShow,
  deleteShow,
  lockSeats,
  unlockSeats,
} from '../controllers/showController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

router
  .route('/')
  .get(getShows)
  .post(protect, authorize('admin'), createShow);

router.post('/:id/lock-seats', protect, lockSeats);
router.post('/:id/unlock-seats', protect, unlockSeats);

router
  .route('/:id')
  .get(getShowById)
  .put(protect, authorize('admin'), updateShow)
  .delete(protect, authorize('admin'), deleteShow);

export default router;
