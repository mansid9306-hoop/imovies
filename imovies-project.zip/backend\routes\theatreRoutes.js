import express from 'express';
import {
  getTheatres,
  getTheatreById,
  createTheatre,
  updateTheatre,
  deleteTheatre,
  getCities,
} from '../controllers/theatreController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/metadata/cities', getCities);

router
  .route('/')
  .get(getTheatres)
  .post(protect, authorize('admin'), createTheatre);

router
  .route('/:id')
  .get(getTheatreById)
  .put(protect, authorize('admin'), updateTheatre)
  .delete(protect, authorize('admin'), deleteTheatre);

export default router;
