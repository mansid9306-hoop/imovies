import mongoose from 'mongoose';
import User from '../models/User.js';
import Movie from '../models/Movie.js';
import Theatre from '../models/Theatre.js';
import Show, { generateSeatLayout } from '../models/Show.js';
import Booking from '../models/Booking.js';
import Payment from '../models/Payment.js';
import Notification from '../models/Notification.js';

export const seedDatabase = async () => {
  console.log('[Seed] Seeding sample cinema data...');

  // 1. Clear existing data
  await Promise.all([
    User.deleteMany(),
    Movie.deleteMany(),
    Theatre.deleteMany(),
    Show.deleteMany(),
    Booking.deleteMany(),
    Payment.deleteMany(),
    Notification.deleteMany(),
  ]);

  // 2. Create Users
  const admin = await User.create({
    name: 'Cinema Admin',
    email: 'admin@imovies.com',
    password: 'admin123',
    role: 'admin',
    phone: '+91 98765 43210',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  });

  const user1 = await User.create({
    name: 'Alex Johnson',
    email: 'alex@example.com',
    password: 'password123',
    role: 'user',
    phone: '+91 91234 56789',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
  });

  const user2 = await User.create({
    name: 'Sophia Miller',
    email: 'sophia@example.com',
    password: 'password123',
    role: 'user',
    phone: '+91 99887 76655',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
  });

  // 3. Create Theatres
  const theatres = await Theatre.insertMany([
    {
      name: 'PVR INOX Superplex Luxe',
      city: 'Mumbai',
      location: 'Phoenix Palladium, Lower Parel',
      address: '462 Senapati Bapat Marg, Lower Parel, Mumbai, MH 400013',
      screens: [
        { screenNumber: 1, name: 'Audi 1 - IMAX 3D Laser', seatingCapacity: 60, tierPricing: { vip: 450, premium: 320, standard: 220 } },
        { screenNumber: 2, name: 'Audi 2 - Dolby Atmos 4K', seatingCapacity: 60, tierPricing: { vip: 400, premium: 280, standard: 200 } },
      ],
      facilities: ['IMAX Laser', 'Dolby Atmos', 'Recliner Seating', 'Gourmet Dining', 'Wheelchair Access', 'Valet Parking'],
    },
    {
      name: 'Cinepolis VIP MegaMall',
      city: 'Bengaluru',
      location: 'Koramangala 7th Block',
      address: 'Forum Mall, Hosur Road, Koramangala, Bengaluru, KA 560095',
      screens: [
        { screenNumber: 1, name: 'VIP Screen 1 - Dolby 7.1', seatingCapacity: 60, tierPricing: { vip: 400, premium: 300, standard: 200 } },
        { screenNumber: 2, name: 'VIP Screen 2 - 4DX Dynamic', seatingCapacity: 60, tierPricing: { vip: 500, premium: 380, standard: 260 } },
      ],
      facilities: ['4DX Motion Seats', 'Dolby 7.1', 'In-seat Service', 'Live Food Counters', 'Free Wi-Fi'],
    },
    {
      name: 'Grand CineStar Horizon',
      city: 'Delhi NCR',
      location: 'Cyber Hub, Gurugram',
      address: 'DLF Cyber City, Phase 2, Gurugram, HR 122002',
      screens: [
        { screenNumber: 1, name: 'Laser Screen 1', seatingCapacity: 60, tierPricing: { vip: 420, premium: 300, standard: 210 } },
      ],
      facilities: ['Dolby Atmos', '4K Christie Projection', 'Cafeteria', 'Elevator Access'],
    },
    {
      name: 'Prasad Multiplex IMAX',
      city: 'Hyderabad',
      location: 'NTR Gardens, Khairatabad',
      address: 'NTR Gardens, Khairatabad, Hyderabad, TS 500004',
      screens: [
        { screenNumber: 1, name: 'Screen 1 - Giant IMAX', seatingCapacity: 60, tierPricing: { vip: 480, premium: 350, standard: 240 } },
      ],
      facilities: ['Massive IMAX Screen', 'Food Court', 'Gaming Arena', 'Ample Parking'],
    },
  ]);

  // 4. Create Movies
  const movies = await Movie.insertMany([
    {
      title: 'Dune: Part Two',
      description: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the universe, he endeavors to prevent a terrible future only he can foresee.',
      genre: ['Sci-Fi', 'Adventure', 'Action'],
      language: ['English', 'Hindi'],
      duration: 166,
      releaseDate: new Date('2024-03-01'),
      poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
      banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1400&q=80',
      trailerUrl: 'https://www.youtube.com/embed/Way9Dexny3w',
      rating: 8.8,
      votesCount: 4120,
      director: 'Denis Villeneuve',
      certificate: 'UA',
      status: 'now_showing',
      cast: [
        { name: 'Timothée Chalamet', role: 'Paul Atreides', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80' },
        { name: 'Zendaya', role: 'Chani', photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80' },
        { name: 'Rebecca Ferguson', role: 'Lady Jessica', photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80' },
      ],
    },
    {
      title: 'Oppenheimer',
      description: 'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb during World War II, exploring both the triumph and profound moral crisis.',
      genre: ['Biography', 'Drama', 'History'],
      language: ['English'],
      duration: 180,
      releaseDate: new Date('2023-07-21'),
      poster: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=600&q=80',
      banner: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1400&q=80',
      trailerUrl: 'https://www.youtube.com/embed/uYPbbksJxIg',
      rating: 8.9,
      votesCount: 5890,
      director: 'Christopher Nolan',
      certificate: 'A',
      status: 'now_showing',
      cast: [
        { name: 'Cillian Murphy', role: 'J. Robert Oppenheimer', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80' },
        { name: 'Emily Blunt', role: 'Katherine Oppenheimer', photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80' },
        { name: 'Robert Downey Jr.', role: 'Lewis Strauss', photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&q=80' },
      ],
    },
    {
      title: 'Spider-Man: Beyond the Spider-Verse',
      description: 'Miles Morales embarks across the Multiverse once again with Gwen Stacy and an elite team of Spider-People to protect its very existence from an unprecedented cosmic menace.',
      genre: ['Animation', 'Action', 'Sci-Fi'],
      language: ['English', 'Hindi', 'Tamil'],
      duration: 140,
      releaseDate: new Date('2025-06-15'),
      poster: 'https://images.unsplash.com/photo-1635805737707-575885ab0820?auto=format&fit=crop&w=600&q=80',
      banner: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=1400&q=80',
      trailerUrl: 'https://www.youtube.com/embed/cqGjhVJWtEg',
      rating: 9.1,
      votesCount: 3200,
      director: 'Joaquim Dos Santos',
      certificate: 'U',
      status: 'now_showing',
      cast: [
        { name: 'Shameik Moore', role: 'Miles Morales (voice)', photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80' },
        { name: 'Hailee Steinfeld', role: 'Gwen Stacy (voice)', photo: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80' },
      ],
    },
    {
      title: 'Interstellar: 10th Anniversary Re-Release',
      description: 'When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft along with a team of researchers to find a new planet for humans.',
      genre: ['Adventure', 'Drama', 'Sci-Fi'],
      language: ['English'],
      duration: 169,
      releaseDate: new Date('2024-11-01'),
      poster: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80',
      banner: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1400&q=80',
      trailerUrl: 'https://www.youtube.com/embed/zSWdZVtXT7E',
      rating: 8.7,
      votesCount: 6500,
      director: 'Christopher Nolan',
      certificate: 'UA',
      status: 'now_showing',
      cast: [
        { name: 'Matthew McConaughey', role: 'Joseph Cooper', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80' },
        { name: 'Anne Hathaway', role: 'Dr. Amelia Brand', photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80' },
      ],
    },
    {
      title: 'Gladiator II',
      description: 'Years after witnessing the death of Maximus at the hands of his uncle, Lucius must enter the Colosseum after his home is conquered by tyrannical emperors who lead Rome with an iron fist.',
      genre: ['Action', 'Adventure', 'Drama'],
      language: ['English', 'Hindi'],
      duration: 148,
      releaseDate: new Date('2024-11-15'),
      poster: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80',
      banner: 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=1400&q=80',
      trailerUrl: 'https://www.youtube.com/embed/4rgYUipGJNo',
      rating: 8.4,
      votesCount: 2180,
      director: 'Ridley Scott',
      certificate: 'A',
      status: 'now_showing',
      cast: [
        { name: 'Paul Mescal', role: 'Lucius Verus', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80' },
        { name: 'Pedro Pascal', role: 'Marcus Acacius', photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&q=80' },
        { name: 'Denzel Washington', role: 'Macrinus', photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80' },
      ],
    },
    {
      title: 'Avatar: Fire and Ash',
      description: 'The journey of Jake Sully and Neytiri continues on Pandora as they encounter the Ash People, an aggressive volcanic clan of Na\'vi.',
      genre: ['Action', 'Adventure', 'Fantasy', 'Sci-Fi'],
      language: ['English', 'Hindi'],
      duration: 175,
      releaseDate: new Date('2025-12-19'),
      poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80',
      banner: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1400&q=80',
      trailerUrl: 'https://www.youtube.com/embed/d9MyW72ELq0',
      rating: 8.6,
      votesCount: 950,
      director: 'James Cameron',
      certificate: 'UA',
      status: 'upcoming',
      cast: [
        { name: 'Sam Worthington', role: 'Jake Sully', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80' },
        { name: 'Zoe Saldaña', role: 'Neytiri', photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80' },
      ],
    },
  ]);

  // 5. Generate Dates (today, tomorrow, day after)
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const dayAfter = new Date();
  dayAfter.setDate(dayAfter.getDate() + 2);
  const dayAfterStr = dayAfter.toISOString().split('T')[0];

  const dates = [todayStr, tomorrowStr, dayAfterStr];
  const times = ['10:30 AM', '02:00 PM', '06:15 PM', '09:45 PM'];

  // 6. Create Shows for now_showing movies
  const createdShows = [];
  const nowShowingMovies = movies.filter((m) => m.status === 'now_showing');

  for (const movie of nowShowingMovies) {
    for (let i = 0; i < theatres.length; i++) {
      const theatre = theatres[i];
      const screen = theatre.screens[0];
      const pricing = screen.tierPricing || { vip: 400, premium: 280, standard: 200 };

      for (const date of dates) {
        // Schedule 2 showtimes per date
        const selectedTimes = i % 2 === 0 ? [times[0], times[2]] : [times[1], times[3]];
        for (const time of selectedTimes) {
          const seatMatrix = generateSeatLayout(pricing);

          // Simulate a few seats booked in earlier shows for realism
          if (time === times[0] || time === times[1]) {
            seatMatrix[0].status = 'booked';
            seatMatrix[1].status = 'booked';
            seatMatrix[12].status = 'booked';
            seatMatrix[13].status = 'booked';
          }

          const availableCount = seatMatrix.filter((s) => s.status === 'available').length;

          const show = await Show.create({
            movieId: movie._id,
            theatreId: theatre._id,
            screenName: screen.name,
            showDate: date,
            showTime: time,
            pricing,
            seatMatrix,
            totalSeats: seatMatrix.length,
            availableSeats: availableCount,
          });

          createdShows.push(show);
        }
      }
    }
  }

  // 7. Create Sample Booking for Alex Johnson
  const sampleShow = createdShows[0];
  const bookedSeatIds = ['C5', 'C6'];
  const ticketCost = 2 * (sampleShow.pricing.premium || 280);
  const convFee = 30;
  const taxCost = Math.round((ticketCost + convFee) * 0.18);
  const totalCost = ticketCost + convFee + taxCost;
  const bNum = `IM-${new Date().getFullYear()}-492817`;

  // Update show seats
  sampleShow.seatMatrix.forEach((seat) => {
    if (bookedSeatIds.includes(seat.seatId)) {
      seat.status = 'booked';
      seat.lockedBy = user1._id;
    }
  });
  sampleShow.availableSeats -= bookedSeatIds.length;
  await sampleShow.save();

  const sampleBooking = await Booking.create({
    bookingNumber: bNum,
    userId: user1._id,
    showId: sampleShow._id,
    movieId: sampleShow.movieId,
    theatreId: sampleShow.theatreId,
    seats: bookedSeatIds,
    seatDetails: [
      { seatId: 'C5', tier: 'premium', price: sampleShow.pricing.premium },
      { seatId: 'C6', tier: 'premium', price: sampleShow.pricing.premium },
    ],
    ticketPrice: ticketCost,
    convenienceFee: convFee,
    tax: taxCost,
    totalAmount: totalCost,
    bookingStatus: 'confirmed',
    qrCode: `IMOVIES-TICKET:${bNum}:${sampleShow._id}:${bookedSeatIds.join(',')}`,
  });

  const samplePayment = await Payment.create({
    bookingId: sampleBooking._id,
    userId: user1._id,
    amount: totalCost,
    paymentMethod: 'credit_card',
    transactionId: `TXN-SAMPLE-${Date.now()}`,
    status: 'success',
    paymentDetails: {
      cardLast4: '4242',
      bankName: 'HDFC Priority Cinema Card',
    },
  });

  sampleBooking.paymentId = samplePayment._id;
  await sampleBooking.save();

  // Create notifications
  await Notification.create({
    userId: user1._id,
    title: 'Booking Confirmed!',
    message: `Your booking ${bNum} for Dune: Part Two (C5, C6) is confirmed. Enjoy the show!`,
    type: 'booking',
  });

  console.log(`[Seed] Successfully seeded:`);
  console.log(`  - 3 Users (Admin: admin@imovies.com / admin123, User: alex@example.com / password123)`);
  console.log(`  - ${theatres.length} Theatres`);
  console.log(`  - ${movies.length} Movies`);
  console.log(`  - ${createdShows.length} Scheduled Shows`);
  console.log(`  - 1 Sample Booking & Payment transaction`);
};

export const autoSeedIfEmpty = async () => {
  const count = await Movie.countDocuments();
  if (count === 0) {
    console.log('[Seed] Database is empty. Running auto-seeding...');
    await seedDatabase();
  } else {
    console.log(`[Seed] Database already populated (${count} movies present). Skipping auto-seed.`);
  }
};

// Standalone execution: node seeds/seedData.js
if (process.argv[1] && process.argv[1].endsWith('seedData.js')) {
  import('dotenv').then((dotenv) => {
    dotenv.config();
    import('../config/db.js').then(async ({ connectDB }) => {
      await connectDB();
      await seedDatabase();
      console.log('[Seed] Standalone seed complete. Exiting.');
      process.exit(0);
    });
  });
}
