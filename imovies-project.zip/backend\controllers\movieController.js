import Movie from '../models/Movie.js';
import Show from '../models/Show.js';

// @desc    Get all movies with filtering, search, sorting & pagination
// @route   GET /api/movies
// @access  Public
export const getMovies = async (req, res) => {
  try {
    const {
      search,
      genre,
      language,
      status,
      sortBy = 'rating',
      page = 1,
      limit = 12,
    } = req.query;

    const query = {};

    // Search by title or description
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { director: { $regex: search, $options: 'i' } },
      ];
    }

    // Filter by genre
    if (genre && genre !== 'all') {
      query.genre = { $in: [new RegExp(genre, 'i')] };
    }

    // Filter by language
    if (language && language !== 'all') {
      query.language = { $in: [new RegExp(language, 'i')] };
    }

    // Filter by status (now_showing / upcoming)
    if (status && status !== 'all') {
      query.status = status;
    }

    // Sorting
    let sortOptions = {};
    if (sortBy === 'rating') sortOptions = { rating: -1 };
    else if (sortBy === 'latest') sortOptions = { releaseDate: -1 };
    else if (sortBy === 'title') sortOptions = { title: 1 };
    else sortOptions = { createdAt: -1 };

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 12;
    const skip = (pageNum - 1) * limitNum;

    const total = await Movie.countDocuments(query);
    const movies = await Movie.find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(limitNum);

    res.json({
      success: true,
      count: movies.length,
      total,
      totalPages: Math.ceil(total / limitNum),
      currentPage: pageNum,
      data: movies,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single movie by ID with available show dates
// @route   GET /api/movies/:id
// @access  Public
export const getMovieById = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) {
      return res.status(404).json({ success: false, message: 'Movie not found' });
    }

    // Fetch shows available for this movie
    const shows = await Show.find({ movieId: movie._id })
      .populate('theatreId', 'name city location address facilities')
      .sort({ showDate: 1, showTime: 1 });

    res.json({
      success: true,
      data: {
        ...movie.toObject(),
        shows,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new movie
// @route   POST /api/movies
// @access  Private/Admin
export const createMovie = async (req, res) => {
  try {
    const movie = await Movie.create(req.body);
    res.status(201).json({ success: true, data: movie });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Update movie
// @route   PUT /api/movies/:id
// @access  Private/Admin
export const updateMovie = async (req, res) => {
  try {
    const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!movie) {
      return res.status(404).json({ success: false, message: 'Movie not found' });
    }

    res.json({ success: true, data: movie });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete movie
// @route   DELETE /api/movies/:id
// @access  Private/Admin
export const deleteMovie = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) {
      return res.status(404).json({ success: false, message: 'Movie not found' });
    }

    // Also delete associated shows
    await Show.deleteMany({ movieId: movie._id });
    await movie.deleteOne();

    res.json({ success: true, message: 'Movie and associated shows deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get distinct genres and languages for filter dropdowns
// @route   GET /api/movies/metadata/filters
// @access  Public
export const getMovieFilterMetadata = async (req, res) => {
  try {
    const genres = await Movie.distinct('genre');
    const languages = await Movie.distinct('language');
    res.json({ success: true, data: { genres, languages } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
