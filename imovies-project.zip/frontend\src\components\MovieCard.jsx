import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Clock, Ticket } from 'lucide-react';

const MovieCard = ({ movie }) => {
  const formatDuration = (minutes) => {
    if (!minutes) return '';
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hrs}h ${mins}m`;
  };

  return (
    <div className="cinema-card h-100 d-flex flex-column">
      {/* Poster Image Container */}
      <div className="position-relative overflow-hidden" style={{ paddingTop: '145%' }}>
        <img
          src={movie.poster}
          alt={movie.title}
          className="position-absolute top-0 start-0 w-100 h-100 object-fit-cover"
          style={{ transition: 'transform 0.4s ease' }}
          loading="lazy"
          onError={(e) => {
            e.target.src = 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80';
          }}
        />

        {/* Rating Badge */}
        <div
          className="position-absolute top-0 start-0 m-2 px-2 py-1 rounded-pill d-flex align-items-center gap-1 shadow-sm"
          style={{ background: 'rgba(15, 23, 42, 0.85)', backdropFilter: 'blur(6px)', border: '1px solid rgba(255,255,255,0.15)' }}
        >
          <Star size={13} className="text-warning fill-warning" />
          <span className="text-white fw-bold" style={{ fontSize: '12px' }}>
            {movie.rating ? movie.rating.toFixed(1) : '8.0'}
          </span>
        </div>

        {/* Certificate Tag */}
        {movie.certificate && (
          <div
            className="position-absolute top-0 end-0 m-2 px-2 py-0.5 rounded text-white fw-bold shadow-sm"
            style={{ fontSize: '11px', background: 'rgba(229, 9, 20, 0.85)' }}
          >
            {movie.certificate}
          </div>
        )}

        {/* Status Overlay if upcoming */}
        {movie.status === 'upcoming' && (
          <div
            className="position-absolute bottom-0 start-0 w-100 py-1 text-center fw-bold"
            style={{ background: 'rgba(245, 158, 11, 0.9)', color: '#0f172a', fontSize: '12px' }}
          >
            RELEASE DATE: {new Date(movie.releaseDate).toLocaleDateString([], { month: 'short', day: 'numeric' })}
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-3 d-flex flex-column flex-grow-1">
        <h6 className="text-white fw-bold mb-1 text-truncate" title={movie.title}>
          {movie.title}
        </h6>

        <div className="d-flex align-items-center gap-2 text-secondary mb-2" style={{ fontSize: '12px' }}>
          {movie.duration && (
            <span className="d-flex align-items-center gap-1">
              <Clock size={12} /> {formatDuration(movie.duration)}
            </span>
          )}
          <span>•</span>
          <span className="text-truncate">{movie.language ? movie.language.join(', ') : 'English'}</span>
        </div>

        <div className="d-flex flex-wrap gap-1 mb-3">
          {movie.genre?.slice(0, 2).map((g) => (
            <span
              key={g}
              className="badge"
              style={{
                background: 'rgba(255, 255, 255, 0.06)',
                color: '#cbd5e1',
                fontSize: '10px',
                fontWeight: 500,
                border: '1px solid rgba(255, 255, 255, 0.08)',
              }}
            >
              {g}
            </span>
          ))}
        </div>

        {/* Action Button */}
        <div className="mt-auto">
          {movie.status === 'upcoming' ? (
            <Link
              to={`/movies/${movie._id}`}
              className="btn btn-sm btn-outline-secondary w-100 py-2 rounded-3 text-light"
            >
              View Trailer & Details
            </Link>
          ) : (
            <Link
              to={`/movies/${movie._id}`}
              className="btn btn-sm glow-btn w-100 py-2 rounded-3 d-flex align-items-center justify-content-center gap-2"
            >
              <Ticket size={16} /> Book Tickets
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
