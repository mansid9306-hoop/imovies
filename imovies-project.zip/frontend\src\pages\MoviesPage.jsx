import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../services/api';
import MovieCard from '../components/MovieCard';
import { Search, Filter, RotateCcw, Film } from 'lucide-react';

const MoviesPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [genre, setGenre] = useState(searchParams.get('genre') || 'all');
  const [language, setLanguage] = useState(searchParams.get('language') || 'all');
  const [status, setStatus] = useState(searchParams.get('status') || 'all');
  const [sortBy, setSortBy] = useState('rating');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  const [availableGenres, setAvailableGenres] = useState([]);
  const [availableLanguages, setAvailableLanguages] = useState([]);

  // Fetch filter metadata
  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const res = await api.get('/movies/metadata/filters');
        if (res.data.success) {
          setAvailableGenres(res.data.data.genres || []);
          setAvailableLanguages(res.data.data.languages || []);
        }
      } catch (err) {
        console.error('Failed to load filter metadata', err);
      }
    };
    fetchMetadata();
  }, []);

  // Fetch movies based on filters
  useEffect(() => {
    const fetchMovies = async () => {
      setLoading(true);
      try {
        const params = {
          page: currentPage,
          limit: 12,
          sortBy,
        };

        if (search) params.search = search;
        if (genre !== 'all') params.genre = genre;
        if (language !== 'all') params.language = language;
        if (status !== 'all') params.status = status;

        const res = await api.get('/movies', { params });
        if (res.data.success) {
          setMovies(res.data.data);
          setTotalPages(res.data.totalPages || 1);
          setTotalCount(res.data.total || 0);
        }
      } catch (err) {
        console.error('Failed to fetch movies', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, [search, genre, language, status, sortBy, currentPage]);

  const handleReset = () => {
    setSearch('');
    setGenre('all');
    setLanguage('all');
    setStatus('all');
    setSortBy('rating');
    setCurrentPage(1);
  };

  return (
    <div className="container py-4">
      {/* Page Header */}
      <div className="mb-4">
        <h2 className="fw-black text-white mb-1">Movie Catalog</h2>
        <p className="text-secondary small mb-0">
          Explore movies running across leading cinemas, view schedules & reserve seats
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="cinema-card p-3 p-md-4 mb-4">
        <div className="row g-3">
          {/* Search Box */}
          <div className="col-12 col-lg-4">
            <label className="text-secondary small mb-1">Search Movie / Cast</label>
            <div className="position-relative">
              <Search
                size={16}
                className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
              />
              <input
                type="text"
                className="form-control cinema-input ps-5"
                placeholder="Search title, actor..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setCurrentPage(1);
                }}
              />
            </div>
          </div>

          {/* Status Filter */}
          <div className="col-6 col-sm-4 col-lg-2">
            <label className="text-secondary small mb-1">Status</label>
            <select
              className="form-select cinema-input"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setCurrentPage(1);
              }}
            >
              <option value="all">All Movies</option>
              <option value="now_showing">Now Showing</option>
              <option value="upcoming">Upcoming</option>
            </select>
          </div>

          {/* Genre Filter */}
          <div className="col-6 col-sm-4 col-lg-2">
            <label className="text-secondary small mb-1">Genre</label>
            <select
              className="form-select cinema-input"
              value={genre}
              onChange={(e) => {
                setGenre(e.target.value);
                setCurrentPage(1);
              }}
            >
              <option value="all">All Genres</option>
              {availableGenres.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          {/* Language Filter */}
          <div className="col-6 col-sm-4 col-lg-2">
            <label className="text-secondary small mb-1">Language</label>
            <select
              className="form-select cinema-input"
              value={language}
              onChange={(e) => {
                setLanguage(e.target.value);
                setCurrentPage(1);
              }}
            >
              <option value="all">All Languages</option>
              {availableLanguages.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By Filter */}
          <div className="col-6 col-sm-4 col-lg-2">
            <label className="text-secondary small mb-1">Sort By</label>
            <select
              className="form-select cinema-input"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="rating">Top Rated</option>
              <option value="latest">Release Date</option>
              <option value="title">Alphabetical</option>
            </select>
          </div>
        </div>

        {/* Active Filter Indicators & Reset */}
        <div className="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary border-opacity-25">
          <span className="text-secondary small">
            Showing <strong className="text-white">{movies.length}</strong> of{' '}
            <strong className="text-white">{totalCount}</strong> movies
          </span>

          <button
            type="button"
            className="btn btn-sm btn-link text-secondary text-decoration-none d-flex align-items-center gap-1 hover-white p-0"
            onClick={handleReset}
          >
            <RotateCcw size={14} /> Reset Filters
          </button>
        </div>
      </div>

      {/* Movies Grid */}
      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-danger" role="status"></div>
        </div>
      ) : movies.length === 0 ? (
        <div className="cinema-card p-5 text-center my-4">
          <Film size={48} className="text-secondary mb-3" />
          <h5 className="text-white">No Movies Found</h5>
          <p className="text-secondary small mb-3">
            No titles match the selected criteria. Try removing some filters.
          </p>
          <button className="btn btn-sm glow-btn" onClick={handleReset}>
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 mb-5">
          {movies.map((movie) => (
            <div key={movie._id} className="col">
              <MovieCard movie={movie} />
            </div>
          ))}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center gap-2 mb-5">
          <button
            className="btn btn-sm btn-outline-secondary"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
          >
            Previous
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pg) => (
            <button
              key={pg}
              className={`btn btn-sm ${
                currentPage === pg ? 'glow-btn' : 'btn-outline-secondary text-light'
              }`}
              onClick={() => setCurrentPage(pg)}
            >
              {pg}
            </button>
          ))}
          <button
            className="btn btn-sm btn-outline-secondary"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default MoviesPage;
