import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import TicketModal from '../components/TicketModal';
import {
  Ticket,
  Calendar,
  Clock,
  MapPin,
  XCircle,
  AlertTriangle,
  RotateCcw,
  CheckCircle,
  Film,
} from 'lucide-react';

const UserBookingsPage = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('upcoming');
  const [selectedTicket, setSelectedTicket] = useState(null);

  // Cancellation modal state
  const [cancellingBooking, setCancellingBooking] = useState(null);
  const [cancelReason, setCancelReason] = useState('Change of plans');
  const [isCancelling, setIsCancelling] = useState(false);
  const [cancelSuccessMsg, setCancelSuccessMsg] = useState('');

  const fetchBookings = async () => {
    try {
      setLoading(true);
      const res = await api.get('/bookings/my-bookings');
      if (res.data.success) {
        setBookings(res.data.data);
      }
    } catch (err) {
      console.error('Failed to load bookings', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleCancelBooking = async () => {
    if (!cancellingBooking) return;
    setIsCancelling(true);
    try {
      const res = await api.put(`/bookings/${cancellingBooking._id}/cancel`, {
        reason: cancelReason,
      });
      if (res.data.success) {
        setCancelSuccessMsg(
          `Booking ${cancellingBooking.bookingNumber} successfully cancelled. Refund of ₹${res.data.data.refundAmount} initiated.`
        );
        setCancellingBooking(null);
        fetchBookings();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to cancel booking');
    } finally {
      setIsCancelling(false);
    }
  };

  const upcomingBookings = bookings.filter((b) => b.bookingStatus === 'confirmed');
  const pastOrCancelledBookings = bookings.filter((b) => b.bookingStatus === 'cancelled');

  const displayedBookings = activeTab === 'upcoming' ? upcomingBookings : pastOrCancelledBookings;

  return (
    <div className="container py-4">
      {/* Header */}
      <div className="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-4 pb-3 border-bottom border-secondary border-opacity-25">
        <div>
          <h2 className="fw-black text-white mb-1">My Cinema Bookings</h2>
          <p className="text-secondary small mb-0">
            Access your booked tickets, show barcode passes, or manage cancellations
          </p>
        </div>
        <Link to="/movies" className="btn glow-btn btn-sm d-flex align-items-center gap-2">
          <Film size={16} /> Book More Tickets
        </Link>
      </div>

      {cancelSuccessMsg && (
        <div className="alert alert-success d-flex align-items-center justify-content-between mb-4">
          <div className="d-flex align-items-center gap-2">
            <CheckCircle size={18} />
            <span>{cancelSuccessMsg}</span>
          </div>
          <button
            type="button"
            className="btn-close"
            onClick={() => setCancelSuccessMsg('')}
          ></button>
        </div>
      )}

      {/* Tabs */}
      <div className="d-flex gap-2 mb-4">
        <button
          className={`btn btn-sm px-4 py-2 rounded-pill transition ${
            activeTab === 'upcoming' ? 'glow-btn' : 'btn-outline-secondary text-light'
          }`}
          onClick={() => setActiveTab('upcoming')}
        >
          Active Bookings ({upcomingBookings.length})
        </button>
        <button
          className={`btn btn-sm px-4 py-2 rounded-pill transition ${
            activeTab === 'history' ? 'glow-btn' : 'btn-outline-secondary text-light'
          }`}
          onClick={() => setActiveTab('history')}
        >
          Past / Cancelled ({pastOrCancelledBookings.length})
        </button>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-danger" role="status"></div>
        </div>
      ) : displayedBookings.length === 0 ? (
        <div className="cinema-card p-5 text-center my-4">
          <Ticket size={48} className="text-secondary mb-3" />
          <h5 className="text-white">No {activeTab} bookings found</h5>
          <p className="text-secondary small mb-3">
            {activeTab === 'upcoming'
              ? "You don't have any active cinema reservations at the moment."
              : 'You have no cancelled or past tickets.'}
          </p>
          <Link to="/movies" className="btn btn-sm glow-btn">
            Browse Movies & Showtimes
          </Link>
        </div>
      ) : (
        <div className="d-flex flex-column gap-3 mb-5">
          {displayedBookings.map((b) => {
            const movie = b.movieId || {};
            const theatre = b.theatreId || {};
            const show = b.showId || {};

            return (
              <div key={b._id} className="cinema-card p-3 p-md-4">
                <div className="row g-3 align-items-center">
                  {/* Poster Thumbnail */}
                  <div className="col-12 col-sm-3 col-md-2 text-center text-sm-start">
                    <img
                      src={movie.poster}
                      alt={movie.title}
                      className="rounded-3 shadow-sm object-fit-cover w-100"
                      style={{ maxHeight: '130px', maxWidth: '100px' }}
                    />
                  </div>

                  {/* Booking Details */}
                  <div className="col-12 col-sm-9 col-md-6">
                    <div className="d-flex align-items-center gap-2 mb-1">
                      <h5 className="text-white fw-bold mb-0">{movie.title}</h5>
                      <span
                        className={`badge ${
                          b.bookingStatus === 'confirmed' ? 'badge-blue' : 'badge-red'
                        }`}
                      >
                        {b.bookingStatus?.toUpperCase()}
                      </span>
                    </div>

                    <div className="text-secondary small mb-2">
                      <MapPin size={14} className="text-danger me-1" />
                      {theatre.name} - {show.screenName || 'Screen 1'} ({theatre.city})
                    </div>

                    <div className="d-flex flex-wrap gap-3 text-light small mb-2">
                      <span className="d-flex align-items-center gap-1">
                        <Calendar size={13} className="text-warning" /> {show.showDate}
                      </span>
                      <span className="d-flex align-items-center gap-1">
                        <Clock size={13} className="text-info" /> {show.showTime}
                      </span>
                    </div>

                    <div className="d-flex align-items-center gap-2">
                      <span className="text-secondary small">Seats:</span>
                      <span className="badge badge-gold fs-6">{b.seats?.join(', ')}</span>
                      <span className="text-secondary small ms-2 font-monospace">
                        Ref: {b.bookingNumber}
                      </span>
                    </div>
                  </div>

                  {/* Actions & Price */}
                  <div className="col-12 col-md-4 text-md-end border-top-md border-secondary border-opacity-25 pt-3 pt-md-0">
                    <div className="mb-2">
                      <span className="text-secondary small d-block">Amount Paid</span>
                      <strong className="text-success fs-5">₹{b.totalAmount}</strong>
                      {b.bookingStatus === 'cancelled' && b.refundAmount > 0 && (
                        <span className="text-warning small d-block">
                          Refunded: ₹{b.refundAmount}
                        </span>
                      )}
                    </div>

                    <div className="d-flex flex-wrap justify-content-md-end gap-2">
                      <button
                        className="btn btn-sm btn-outline-light d-flex align-items-center gap-1"
                        onClick={() => setSelectedTicket(b)}
                      >
                        <Ticket size={14} /> View Ticket
                      </button>

                      {b.bookingStatus === 'confirmed' && (
                        <button
                          className="btn btn-sm btn-outline-danger d-flex align-items-center gap-1"
                          onClick={() => setCancellingBooking(b)}
                        >
                          <XCircle size={14} /> Cancel
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Ticket Modal */}
      {selectedTicket && (
        <TicketModal booking={selectedTicket} onClose={() => setSelectedTicket(null)} />
      )}

      {/* Cancellation Confirmation Dialog */}
      {cancellingBooking && (
        <div
          className="modal fade show d-block"
          tabIndex="-1"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', backdropFilter: 'blur(8px)', zIndex: 1060 }}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content cinema-modal border-0 shadow-2xl p-4">
              <div className="d-flex align-items-center gap-2 mb-3 text-warning">
                <AlertTriangle size={24} />
                <h5 className="modal-title fw-bold text-white mb-0">Cancel Ticket Reservation</h5>
              </div>

              <p className="text-secondary small">
                Are you sure you want to cancel booking{' '}
                <strong className="text-white">{cancellingBooking.bookingNumber}</strong> for{' '}
                <strong className="text-white">{cancellingBooking.movieId?.title}</strong>?
              </p>

              <div className="p-3 rounded bg-dark bg-opacity-75 border border-secondary border-opacity-25 mb-3">
                <div className="d-flex justify-content-between text-secondary small mb-1">
                  <span>Seats:</span>
                  <span className="text-white fw-bold">{cancellingBooking.seats?.join(', ')}</span>
                </div>
                <div className="d-flex justify-content-between text-secondary small mb-1">
                  <span>Original Paid Amount:</span>
                  <span className="text-white">₹{cancellingBooking.totalAmount}</span>
                </div>
                <div className="d-flex justify-content-between text-success fw-bold small pt-2 border-top border-secondary border-opacity-25">
                  <span>Refund Amount (85%):</span>
                  <span>₹{Math.round(cancellingBooking.ticketPrice * 0.85)}</span>
                </div>
              </div>

              <div className="mb-3">
                <label className="text-secondary small mb-1">Reason for Cancellation</label>
                <select
                  className="form-select cinema-input text-white"
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                >
                  <option value="Change of plans">Change of plans</option>
                  <option value="Booked by mistake">Booked wrong movie/time</option>
                  <option value="Emergency">Emergency</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="d-flex justify-content-end gap-2 mt-2">
                <button
                  type="button"
                  className="btn btn-outline-secondary btn-sm"
                  onClick={() => setCancellingBooking(null)}
                >
                  Keep Ticket
                </button>
                <button
                  type="button"
                  className="btn btn-danger btn-sm px-3"
                  disabled={isCancelling}
                  onClick={handleCancelBooking}
                >
                  {isCancelling ? 'Processing Refund...' : 'Confirm Cancellation'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserBookingsPage;
