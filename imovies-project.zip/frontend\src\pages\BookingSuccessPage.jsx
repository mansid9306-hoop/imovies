import React, { useState, useEffect } from 'react';
import { useParams, useLocation, Link, useNavigate } from 'react-router-dom';
import api from '../services/api';
import TicketModal from '../components/TicketModal';
import { CheckCircle, Ticket, Printer, Film, ArrowRight } from 'lucide-react';

const BookingSuccessPage = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const [booking, setBooking] = useState(location.state?.booking || null);
  const [loading, setLoading] = useState(!location.state?.booking);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (!booking && id) {
      const fetchBooking = async () => {
        try {
          const res = await api.get(`/bookings/${id}`);
          if (res.data.success) {
            setBooking(res.data.data);
          }
        } catch (err) {
          console.error(err);
        } finally {
          setLoading(false);
        }
      };
      fetchBooking();
    }
  }, [id, booking]);

  if (loading) {
    return (
      <div className="d-flex align-items-center justify-content-center min-vh-50 py-5">
        <div className="spinner-border text-danger" role="status"></div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="container py-5 text-center">
        <h4 className="text-white">Booking details not found</h4>
        <Link to="/my-bookings" className="btn btn-sm glow-btn mt-3">
          Go to My Bookings
        </Link>
      </div>
    );
  }

  const movie = booking.movieId || {};
  const theatre = booking.theatreId || {};
  const show = booking.showId || {};

  return (
    <div className="container py-5">
      <div className="text-center mb-5">
        <div
          className="d-inline-flex p-3 rounded-circle mb-3"
          style={{ background: 'rgba(16, 185, 129, 0.15)', color: '#10b981' }}
        >
          <CheckCircle size={48} />
        </div>
        <h2 className="fw-black text-white mb-2">Booking Confirmed!</h2>
        <p className="text-secondary" style={{ maxWidth: '500px', margin: '0 auto' }}>
          Your cinema seats have been successfully reserved. We have emailed your official e-ticket pass.
        </p>
      </div>

      <div className="row justify-content-center">
        <div className="col-12 col-md-8 col-lg-7">
          <div className="ticket-wrapper mb-4">
            <div className="ticket-notch-left"></div>
            <div className="ticket-notch-right"></div>

            <div className="d-flex justify-content-between align-items-center pb-3 mb-3 border-bottom border-secondary border-opacity-25">
              <div>
                <span className="text-secondary small d-block">Booking Reference</span>
                <strong className="text-warning font-monospace fs-5">{booking.bookingNumber}</strong>
              </div>
              <span className="badge badge-blue">CONFIRMED</span>
            </div>

            <div className="row g-3 align-items-center mb-4">
              <div className="col-4 col-sm-3 text-center">
                <img
                  src={movie.poster}
                  alt={movie.title}
                  className="rounded-3 shadow-md w-100 object-fit-cover"
                  style={{ maxHeight: '160px' }}
                />
              </div>
              <div className="col-8 col-sm-9">
                <h4 className="text-white fw-bold mb-1">{movie.title}</h4>
                <p className="text-secondary small mb-2">{theatre.name} - {show.screenName}</p>
                <div className="d-flex flex-wrap gap-3 text-light small mb-2">
                  <span>Date: <strong>{show.showDate}</strong></span>
                  <span>Time: <strong>{show.showTime}</strong></span>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <span className="text-secondary small">Seats:</span>
                  <span className="badge badge-gold fs-6">{booking.seats?.join(', ')}</span>
                </div>
              </div>
            </div>

            <div className="d-flex justify-content-between align-items-center pt-3 border-top border-secondary border-opacity-25">
              <div>
                <span className="text-secondary small d-block">Total Paid</span>
                <strong className="text-success fs-5">₹{booking.totalAmount}</strong>
              </div>
              <button
                className="btn glow-btn btn-sm d-flex align-items-center gap-2 px-3 py-2"
                onClick={() => setShowModal(true)}
              >
                <Ticket size={16} /> View Full E-Ticket
              </button>
            </div>
          </div>

          <div className="d-flex flex-wrap justify-content-center gap-3">
            <Link to="/my-bookings" className="btn btn-outline-light px-4 py-2 rounded-3">
              View All My Bookings
            </Link>
            <Link to="/movies" className="btn btn-danger px-4 py-2 rounded-3 d-flex align-items-center gap-2">
              <Film size={16} /> Book Another Movie <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </div>

      {showModal && <TicketModal booking={booking} onClose={() => setShowModal(false)} />}
    </div>
  );
};

export default BookingSuccessPage;
