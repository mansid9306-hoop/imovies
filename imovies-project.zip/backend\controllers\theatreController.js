import Theatre from '../models/Theatre.js';
import Show from '../models/Show.js';

// @desc    Get all theatres with optional city filter
// @route   GET /api/theatres
// @access  Public
export const getTheatres = async (req, res) => {
  try {
    const { city, search } = req.query;
    const query = {};

    if (city && city !== 'all') {
      query.city = { $regex: new RegExp(`^${city}$`, 'i') };
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
        { city: { $regex: search, $options: 'i' } },
      ];
    }

    const theatres = await Theatre.find(query).sort({ name: 1 });
    res.json({ success: true, count: theatres.length, data: theatres });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single theatre by ID
// @route   GET /api/theatres/:id
// @access  Public
export const getTheatreById = async (req, res) => {
  try {
    const theatre = await Theatre.findById(req.params.id);
    if (!theatre) {
      return res.status(404).json({ success: false, message: 'Theatre not found' });
    }

    // Get current shows at this theatre
    const shows = await Show.find({ theatreId: theatre._id })
      .populate('movieId', 'title poster duration rating certificate genre language')
      .sort({ showDate: 1, showTime: 1 });

    res.json({
      success: true,
      data: {
        ...theatre.toObject(),
        shows,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new theatre
// @route   POST /api/theatres
// @access  Private/Admin
export const createTheatre = async (req, res) => {
  try {
    const theatre = await Theatre.create(req.body);
    res.status(201).json({ success: true, data: theatre });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Update theatre
// @route   PUT /api/theatres/:id
// @access  Private/Admin
export const updateTheatre = async (req, res) => {
  try {
    const theatre = await Theatre.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!theatre) {
      return res.status(404).json({ success: false, message: 'Theatre not found' });
    }
    res.json({ success: true, data: theatre });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete theatre
// @route   DELETE /api/theatres/:id
// @access  Private/Admin
export const deleteTheatre = async (req, res) => {
  try {
    const theatre = await Theatre.findById(req.params.id);
    if (!theatre) {
      return res.status(404).json({ success: false, message: 'Theatre not found' });
    }

    await Show.deleteMany({ theatreId: theatre._id });
    await theatre.deleteOne();

    res.json({ success: true, message: 'Theatre and associated shows deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all distinct cities
// @route   GET /api/theatres/metadata/cities
// @access  Public
export const getCities = async (req, res) => {
  try {
    const cities = await Theatre.distinct('city');
    res.json({ success: true, data: cities });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
