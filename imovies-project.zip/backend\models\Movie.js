import mongoose from 'mongoose';

const castSchema = new mongoose.Schema({
  name: { type: String, required: true },
  role: { type: String, default: '' },
  photo: { type: String, default: '' }
}, { _id: false });

const movieSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Movie title is required'],
      trim: true,
      index: true,
    },
    description: {
      type: String,
      required: [true, 'Movie description is required'],
    },
    genre: {
      type: [String],
      required: true,
      index: true,
    },
    language: {
      type: [String],
      required: true,
      index: true,
    },
    duration: {
      type: Number, // Duration in minutes
      required: true,
    },
    releaseDate: {
      type: Date,
      required: true,
    },
    poster: {
      type: String,
      required: [true, 'Movie poster URL is required'],
    },
    banner: {
      type: String,
      default: '',
    },
    trailerUrl: {
      type: String,
      default: '',
    },
    rating: {
      type: Number,
      default: 8.0,
      min: 0,
      max: 10,
    },
    votesCount: {
      type: Number,
      default: 120,
    },
    director: {
      type: String,
      default: 'Unknown',
    },
    certificate: {
      type: String,
      default: 'UA',
    },
    cast: [castSchema],
    status: {
      type: String,
      enum: ['now_showing', 'upcoming'],
      default: 'now_showing',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// Compound text index for title & description search
movieSchema.index({ title: 'text', description: 'text' });

const Movie = mongoose.model('Movie', movieSchema);
import { createModelAdapter } from '../utils/memoryStore.js';
export default createModelAdapter('movies', Movie);
