import Payment from '../models/Payment.js';

// @desc    Process simulated payment
// @route   POST /api/payments/process
// @access  Private
export const processPayment = async (req, res) => {
  try {
    const { amount, paymentMethod = 'credit_card', cardDetails, upiId } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid payment amount' });
    }

    // Simulate 200ms processing delay
    await new Promise((resolve) => setTimeout(resolve, 300));

    // Simulated Gateway Result
    const transactionId = `TXN-${Date.now()}-${Math.floor(100000 + Math.random() * 900000)}`;

    res.json({
      success: true,
      message: 'Payment authorized and processed successfully',
      data: {
        transactionId,
        amount,
        paymentMethod,
        status: 'success',
        timestamp: new Date(),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get payment by transaction ID
// @route   GET /api/payments/transaction/:id
// @access  Private
export const getPaymentByTransactionId = async (req, res) => {
  try {
    const payment = await Payment.findOne({ transactionId: req.params.id })
      .populate('bookingId')
      .populate('userId', 'name email');

    if (!payment) {
      return res.status(404).json({ success: false, message: 'Transaction record not found' });
    }

    res.json({ success: true, data: payment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
