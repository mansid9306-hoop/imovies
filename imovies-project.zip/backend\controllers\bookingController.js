import Booking from '../models/Booking.js';
import Show from '../models/Show.js';
import Payment from '../models/Payment.js';
import Notification from '../models/Notification.js';

// @desc    Create new booking and process simulated payment
// @route   POST /api/bookings
// @access  Private
export const createBooking = async (req, res) => {
  try {
    const { showId, seatIds, paymentMethod = 'credit_card', paymentDetails = {} } = req.body;

    if (!showId || !seatIds || !Array.isArray(seatIds) || seatIds.length === 0) {
      return res.status(400).json({ success: false, message: 'Show ID and seat IDs are required' });
    }

    const show = await Show.findById(showId)
      .populate('movieId')
      .populate('theatreId');

    if (!show) {
      return res.status(404).json({ success: false, message: 'Show not found' });
    }

    // Verify seats
    const seatDetails = [];
    let ticketPrice = 0;

    for (const seatId of seatIds) {
      const seat = show.seatMatrix.find((s) => s.seatId === seatId);
      if (!seat) {
        return res.status(400).json({ success: false, message: `Seat ${seatId} does not exist` });
      }

      if (seat.status === 'booked') {
        return res.status(409).json({ success: false, message: `Seat ${seatId} is already booked` });
      }

      // If locked, verify it was locked by this user
      if (
        seat.status === 'locked' &&
        seat.lockedBy &&
        seat.lockedBy.toString() !== req.user._id.toString()
      ) {
        return res.status(409).json({ success: false, message: `Seat ${seatId} is locked by another customer` });
      }

      seatDetails.push({
        seatId: seat.seatId,
        tier: seat.tier,
        price: seat.price,
      });

      ticketPrice += seat.price;
    }

    // Calculate fees
    const convenienceFee = Math.round(seatIds.length * 15);
    const tax = Math.round((ticketPrice + convenienceFee) * 0.18);
    const totalAmount = ticketPrice + convenienceFee + tax;

    // Generate unique booking number
    const randomDigits = Math.floor(100000 + Math.random() * 900000);
    const bookingNumber = `IM-${new Date().getFullYear()}-${randomDigits}`;

    // Mark seats as booked in Show
    show.seatMatrix.forEach((seat) => {
      if (seatIds.includes(seat.seatId)) {
        seat.status = 'booked';
        seat.lockedBy = req.user._id;
        seat.lockExpiry = null;
      }
    });
    show.availableSeats = show.seatMatrix.filter((s) => s.status === 'available').length;
    await show.save();

    // Create Booking
    const booking = await Booking.create({
      bookingNumber,
      userId: req.user._id,
      showId: show._id,
      movieId: show.movieId._id,
      theatreId: show.theatreId._id,
      seats: seatIds,
      seatDetails,
      ticketPrice,
      convenienceFee,
      tax,
      totalAmount,
      bookingStatus: 'confirmed',
      qrCode: `IMOVIES-TICKET:${bookingNumber}:${show._id}:${seatIds.join(',')}`,
    });

    // Create Payment Record
    const transactionId = `TXN-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const payment = await Payment.create({
      bookingId: booking._id,
      userId: req.user._id,
      amount: totalAmount,
      paymentMethod,
      transactionId,
      status: 'success',
      paymentDetails: {
        cardLast4: paymentDetails.cardLast4 || '4242',
        upiId: paymentDetails.upiId || '',
        bankName: paymentDetails.bankName || 'CinemaPay Partner Bank',
      },
    });

    // Link payment to booking
    booking.paymentId = payment._id;
    await booking.save();

    // Create Notification
    await Notification.create({
      userId: req.user._id,
      title: 'Booking Confirmed!',
      message: `Your booking ${bookingNumber} for "${show.movieId.title}" (${seatIds.join(', ')}) on ${show.showDate} at ${show.showTime} is confirmed.`,
      type: 'booking',
    });

    // Broadcast real-time seat update via Socket.io
    if (req.io) {
      req.io.to(`show_${show._id}`).emit('seats_updated', {
        showId: show._id,
        seatMatrix: show.seatMatrix,
        availableSeats: show.availableSeats,
      });
    }

    const populatedBooking = await Booking.findById(booking._id)
      .populate('movieId')
      .populate('theatreId')
      .populate('showId')
      .populate('paymentId');

    res.status(201).json({
      success: true,
      message: 'Tickets booked successfully!',
      data: populatedBooking,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get logged in user bookings
// @route   GET /api/bookings/my-bookings
// @access  Private
export const getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.user._id })
      .populate('movieId', 'title poster duration rating certificate genre language')
      .populate('theatreId', 'name city location address facilities')
      .populate('showId', 'showDate showTime screenName')
      .populate('paymentId')
      .sort({ createdAt: -1 });

    res.json({ success: true, count: bookings.length, data: bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get booking details by ID
// @route   GET /api/bookings/:id
// @access  Private
export const getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('movieId')
      .populate('theatreId')
      .populate('showId')
      .populate('paymentId')
      .populate('userId', 'name email phone');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    // Only allow owner or admin
    if (
      booking.userId._id.toString() !== req.user._id.toString() &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ success: false, message: 'Unauthorized to view this booking' });
    }

    res.json({ success: true, data: booking });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Cancel booking & refund seats
// @route   PUT /api/bookings/:id/cancel
// @access  Private
export const cancelBooking = async (req, res) => {
  try {
    const { reason = 'Customer request' } = req.body;
    const booking = await Booking.findById(req.params.id)
      .populate('movieId', 'title')
      .populate('showId');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (
      booking.userId.toString() !== req.user._id.toString() &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this booking' });
    }

    if (booking.bookingStatus === 'cancelled') {
      return res.status(400).json({ success: false, message: 'Booking is already cancelled' });
    }

    // Calculate refund (e.g. 85% of total ticket price)
    const refundAmount = Math.round(booking.ticketPrice * 0.85);

    booking.bookingStatus = 'cancelled';
    booking.cancellationReason = reason;
    booking.refundAmount = refundAmount;
    await booking.save();

    // Release seats in Show
    const show = await Show.findById(booking.showId._id);
    if (show) {
      show.seatMatrix.forEach((seat) => {
        if (booking.seats.includes(seat.seatId)) {
          seat.status = 'available';
          seat.lockedBy = null;
          seat.lockExpiry = null;
        }
      });
      show.availableSeats = show.seatMatrix.filter((s) => s.status === 'available').length;
      await show.save();

      // Broadcast seat availability update
      if (req.io) {
        req.io.to(`show_${show._id}`).emit('seats_updated', {
          showId: show._id,
          seatMatrix: show.seatMatrix,
          availableSeats: show.availableSeats,
        });
      }
    }

    // Update payment record to refunded
    if (booking.paymentId) {
      await Payment.findByIdAndUpdate(booking.paymentId, { status: 'refunded' });
    }

    // Notification
    await Notification.create({
      userId: booking.userId,
      title: 'Booking Cancelled',
      message: `Your booking ${booking.bookingNumber} for "${booking.movieId?.title}" has been cancelled. Refund of ₹${refundAmount} has been processed.`,
      type: 'cancellation',
    });

    res.json({
      success: true,
      message: 'Booking cancelled successfully. Refund initiated.',
      data: booking,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all bookings (Admin)
// @route   GET /api/bookings
// @access  Private/Admin
export const getAllBookings = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = {};
    if (status && status !== 'all') {
      query.bookingStatus = status;
    }

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 20;
    const skip = (pageNum - 1) * limitNum;

    const total = await Booking.countDocuments(query);
    const bookings = await Booking.find(query)
      .populate('userId', 'name email phone')
      .populate('movieId', 'title poster')
      .populate('theatreId', 'name city')
      .populate('showId', 'showDate showTime screenName')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);

    res.json({
      success: true,
      total,
      totalPages: Math.ceil(total / limitNum),
      currentPage: pageNum,
      count: bookings.length,
      data: bookings,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
