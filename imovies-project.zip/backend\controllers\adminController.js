import User from '../models/User.js';
import Movie from '../models/Movie.js';
import Theatre from '../models/Theatre.js';
import Show from '../models/Show.js';
import Booking from '../models/Booking.js';
import Payment from '../models/Payment.js';

// @desc    Get Admin Dashboard Analytics
// @route   GET /api/admin/analytics
// @access  Private/Admin
export const getAdminAnalytics = async (req, res) => {
  try {
    const [
      totalUsers,
      totalMovies,
      totalTheatres,
      totalShows,
      totalBookings,
      confirmedBookings,
      cancelledBookings,
    ] = await Promise.all([
      User.countDocuments({ role: 'user' }),
      Movie.countDocuments(),
      Theatre.countDocuments(),
      Show.countDocuments(),
      Booking.countDocuments(),
      Booking.countDocuments({ bookingStatus: 'confirmed' }),
      Booking.countDocuments({ bookingStatus: 'cancelled' }),
    ]);

    // Calculate total revenue from successful payments
    const payments = await Payment.find({ status: 'success' });
    const totalRevenue = payments.reduce((acc, curr) => acc + curr.amount, 0);

    // Calculate total tickets sold
    const confirmedList = await Booking.find({ bookingStatus: 'confirmed' });
    const totalTicketsSold = confirmedList.reduce((acc, curr) => acc + (curr.seats?.length || 0), 0);

    // Recent 10 bookings
    const recentBookings = await Booking.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('userId', 'name email')
      .populate('movieId', 'title')
      .populate('theatreId', 'name city');

    // Revenue per movie
    const movieRevenueAggregation = await Booking.aggregate([
      { $match: { bookingStatus: 'confirmed' } },
      {
        $group: {
          _id: '$movieId',
          revenue: { $sum: '$totalAmount' },
          tickets: { $sum: { $size: '$seats' } },
          bookingsCount: { $sum: 1 },
        },
      },
      { $sort: { revenue: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'movies',
          localField: '_id',
          foreignField: '_id',
          as: 'movieDetails',
        },
      },
      { $unwind: '$movieDetails' },
      {
        $project: {
          title: '$movieDetails.title',
          poster: '$movieDetails.poster',
          revenue: 1,
          tickets: 1,
          bookingsCount: 1,
        },
      },
    ]);

    res.json({
      success: true,
      data: {
        stats: {
          totalUsers,
          totalMovies,
          totalTheatres,
          totalShows,
          totalBookings,
          confirmedBookings,
          cancelledBookings,
          totalRevenue,
          totalTicketsSold,
        },
        recentBookings,
        topMovies: movieRevenueAggregation,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
