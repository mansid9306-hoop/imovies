import React from 'react';
import { Film, Calendar, Clock, MapPin, Printer, X, CheckCircle } from 'lucide-react';

const TicketModal = ({ booking, onClose }) => {
  if (!booking) return null;

  const handlePrint = () => {
    window.print();
  };

  const movie = booking.movieId || {};
  const theatre = booking.theatreId || {};
  const show = booking.showId || {};

  return (
    <div
      className="modal fade show d-block"
      tabIndex="-1"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', backdropFilter: 'blur(8px)', zIndex: 1060 }}
    >
      <div className="modal-dialog modal-dialog-centered modal-lg">
        <div className="modal-content cinema-modal border-0 shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="modal-header border-bottom border-secondary border-opacity-25 px-4 py-3">
            <div className="d-flex align-items-center gap-2">
              <CheckCircle size={20} className="text-success" />
              <h5 className="modal-title text-white fw-bold mb-0">Official Cinema e-Ticket</h5>
            </div>
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary text-white rounded-circle p-1"
              onClick={onClose}
            >
              <X size={18} />
            </button>
          </div>

          {/* Ticket Body */}
          <div className="modal-body p-4">
            <div className="ticket-wrapper">
              <div className="ticket-notch-left"></div>
              <div className="ticket-notch-right"></div>

              <div className="row g-4 align-items-center">
                {/* Left Poster Thumbnail */}
                <div className="col-12 col-md-3 text-center">
                  <img
                    src={movie.poster || 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=300&q=80'}
                    alt={movie.title}
                    className="rounded-3 shadow-md w-100 object-fit-cover"
                    style={{ maxHeight: '220px' }}
                  />
                  <div className="mt-2">
                    <span className="badge badge-gold font-monospace small">
                      {booking.bookingNumber}
                    </span>
                  </div>
                </div>

                {/* Center Ticket Information */}
                <div className="col-12 col-md-6 border-end-md border-secondary border-opacity-25">
                  <h4 className="text-white fw-black mb-1">{movie.title || 'Movie Title'}</h4>
                  <p className="text-secondary small mb-3">
                    {movie.genre?.join(', ')} • {movie.certificate || 'UA'} • {movie.language?.join(', ')}
                  </p>

                  <div className="d-flex flex-column gap-2 mb-3">
                    <div className="d-flex align-items-center gap-2 text-light small">
                      <MapPin size={16} className="text-danger flex-shrink-0" />
                      <span>
                        <strong>{theatre.name}</strong> - {show.screenName || 'Screen 1'}
                        <br />
                        <span className="text-secondary" style={{ fontSize: '11px' }}>
                          {theatre.location}, {theatre.city}
                        </span>
                      </span>
                    </div>

                    <div className="d-flex align-items-center gap-4 text-light small mt-1">
                      <div className="d-flex align-items-center gap-2">
                        <Calendar size={15} className="text-warning" />
                        <span>{show.showDate}</span>
                      </div>
                      <div className="d-flex align-items-center gap-2">
                        <Clock size={15} className="text-info" />
                        <span>{show.showTime}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-2 rounded bg-dark bg-opacity-50 border border-secondary border-opacity-25">
                    <div className="d-flex justify-content-between align-items-center">
                      <div>
                        <span className="text-secondary small d-block">Reserved Seats:</span>
                        <strong className="text-warning fs-5">{booking.seats?.join(', ')}</strong>
                      </div>
                      <div className="text-end">
                        <span className="text-secondary small d-block">Total Paid:</span>
                        <strong className="text-success fs-5">₹{booking.totalAmount}</strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right QR Code & Verification */}
                <div className="col-12 col-md-3 text-center">
                  <div className="p-3 bg-white rounded-3 d-inline-block shadow-sm">
                    {/* Simulated Authentic SVG QR Code */}
                    <svg
                      width="120"
                      height="120"
                      viewBox="0 0 100 100"
                      fill="#0f172a"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect width="100" height="100" fill="#ffffff" />
                      <rect x="10" y="10" width="25" height="25" fill="#0f172a" />
                      <rect x="15" y="15" width="15" height="15" fill="#ffffff" />
                      <rect x="18" y="18" width="9" height="9" fill="#0f172a" />

                      <rect x="65" y="10" width="25" height="25" fill="#0f172a" />
                      <rect x="70" y="15" width="15" height="15" fill="#ffffff" />
                      <rect x="73" y="18" width="9" height="9" fill="#0f172a" />

                      <rect x="10" y="65" width="25" height="25" fill="#0f172a" />
                      <rect x="15" y="70" width="15" height="15" fill="#ffffff" />
                      <rect x="18" y="73" width="9" height="9" fill="#0f172a" />

                      <rect x="42" y="15" width="6" height="6" fill="#0f172a" />
                      <rect x="52" y="25" width="6" height="6" fill="#0f172a" />
                      <rect x="42" y="42" width="16" height="16" fill="#0f172a" />
                      <rect x="65" y="45" width="8" height="8" fill="#0f172a" />
                      <rect x="45" y="70" width="10" height="10" fill="#0f172a" />
                      <rect x="65" y="75" width="12" height="12" fill="#0f172a" />
                      <rect x="80" y="65" width="8" height="8" fill="#0f172a" />
                    </svg>
                  </div>
                  <span className="d-block text-secondary mt-2 font-monospace" style={{ fontSize: '10px' }}>
                    SCAN AT ENTRANCE
                  </span>
                  <span className={`badge mt-1 ${booking.bookingStatus === 'confirmed' ? 'badge-blue' : 'badge-red'}`}>
                    {booking.bookingStatus?.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="modal-footer border-top border-secondary border-opacity-25 px-4 py-3">
            <button type="button" className="btn btn-outline-light btn-sm" onClick={onClose}>
              Close
            </button>
            <button type="button" className="btn glow-btn btn-sm d-flex align-items-center gap-2" onClick={handlePrint}>
              <Printer size={16} /> Print / Save Ticket
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketModal;
