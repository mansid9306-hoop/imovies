import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import { User, Mail, Phone, Lock, CheckCircle, ShieldCheck, Image, Bell } from 'lucide-react';

const UserProfilePage = () => {
  const { user, notifications, markNotificationRead } = useAuth();

  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [avatar, setAvatar] = useState(user?.avatar || '');
  const [password, setPassword] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [saving, setSaving] = useState(false);

  const handleUpdate = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg('');
    setErrorMsg('');

    try {
      const updateData = { name, phone, avatar };
      if (password) updateData.password = password;

      const res = await api.put('/auth/profile', updateData);
      if (res.data.success) {
        setSuccessMsg('Profile updated successfully!');
        localStorage.setItem('imovies_user', JSON.stringify(res.data.data));
        setPassword('');
      }
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="container py-4">
      <div className="mb-4 pb-3 border-bottom border-secondary border-opacity-25">
        <h2 className="fw-black text-white mb-1">Account & Settings</h2>
        <p className="text-secondary small mb-0">Manage your cinema profile and notifications</p>
      </div>

      {successMsg && (
        <div className="alert alert-success d-flex align-items-center gap-2 mb-4">
          <CheckCircle size={18} />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="alert alert-danger mb-4">
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="row g-4">
        {/* Left Column: Avatar & Overview */}
        <div className="col-12 col-md-4">
          <div className="cinema-card p-4 text-center">
            <img
              src={avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'}
              alt={name}
              className="rounded-circle shadow-lg mb-3 object-fit-cover border border-3 border-danger"
              style={{ width: '110px', height: '110px' }}
            />
            <h5 className="text-white fw-bold mb-1">{user?.name}</h5>
            <span className="text-secondary small d-block mb-2">{user?.email}</span>
            <span className="badge badge-gold text-uppercase">{user?.role}</span>

            <div className="mt-4 pt-3 border-top border-secondary border-opacity-25 text-start">
              <span className="text-secondary small d-block mb-1">
                Member ID: <span className="text-white font-monospace">{user?._id?.slice(-8)}</span>
              </span>
              <span className="text-secondary small d-block">
                Status: <span className="text-success fw-bold">Active VIP Member</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Edit Profile Form */}
        <div className="col-12 col-md-8">
          <div className="cinema-card p-4 mb-4">
            <h5 className="text-white fw-bold mb-3 pb-2 border-bottom border-secondary border-opacity-25">
              Personal Information
            </h5>

            <form onSubmit={handleUpdate}>
              <div className="row g-3">
                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Full Name</label>
                  <input
                    type="text"
                    className="form-control cinema-input"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Email Address</label>
                  <input
                    type="email"
                    className="form-control cinema-input text-secondary"
                    value={user?.email}
                    disabled
                  />
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Mobile Phone</label>
                  <input
                    type="tel"
                    className="form-control cinema-input"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Avatar Image URL</label>
                  <input
                    type="url"
                    className="form-control cinema-input"
                    value={avatar}
                    onChange={(e) => setAvatar(e.target.value)}
                    placeholder="https://..."
                  />
                </div>

                <div className="col-12">
                  <label className="text-secondary small mb-1">New Password (leave blank to keep current)</label>
                  <input
                    type="password"
                    className="form-control cinema-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="mt-4 pt-3 border-top border-secondary border-opacity-25 d-flex justify-content-end">
                <button type="submit" className="btn glow-btn px-4" disabled={saving}>
                  {saving ? 'Saving changes...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>

          {/* Activity / Notifications */}
          <div className="cinema-card p-4">
            <h5 className="text-white fw-bold mb-3 pb-2 border-bottom border-secondary border-opacity-25 d-flex align-items-center gap-2">
              <Bell size={18} className="text-danger" /> System Notifications ({notifications.length})
            </h5>

            <div className="d-flex flex-column gap-2" style={{ maxHeight: '280px', overflowY: 'auto' }}>
              {notifications.length === 0 ? (
                <p className="text-secondary small mb-0">No notifications received yet.</p>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n._id}
                    className={`p-3 rounded ${
                      n.read ? 'bg-dark bg-opacity-25' : 'bg-dark bg-opacity-75 border-start border-3 border-warning'
                    }`}
                  >
                    <div className="d-flex justify-content-between align-items-center mb-1">
                      <strong className="text-white small">{n.title}</strong>
                      <span className="text-secondary" style={{ fontSize: '11px' }}>
                        {new Date(n.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-secondary small mb-0">{n.message}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfilePage;
