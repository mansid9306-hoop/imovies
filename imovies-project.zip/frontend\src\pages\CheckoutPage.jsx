import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import {
  CreditCard,
  QrCode,
  Building,
  Wallet,
  ShieldCheck,
  Lock,
  Timer,
  CheckCircle,
  AlertCircle,
  ArrowLeft,
} from 'lucide-react';

const CheckoutPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();

  const bookingState = location.state;

  const [paymentMethod, setPaymentMethod] = useState('credit_card');
  const [processing, setProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Form Fields
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '+91 98765 43210');

  // Card details
  const [cardNumber, setCardNumber] = useState('4242 4242 4242 4242');
  const [expiry, setExpiry] = useState('12/28');
  const [cvv, setCvv] = useState('888');
  const [cardName, setCardName] = useState(user?.name || 'Cardholder');

  // UPI details
  const [upiId, setUpiId] = useState('cinema.fan@okhdfcbank');

  // NetBanking bank selection
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');

  // Timer: 8 minutes lock
  const [timeLeft, setTimeLeft] = useState(480);

  useEffect(() => {
    if (!bookingState) {
      navigate('/movies');
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          alert('Seat reservation session timed out. Please select your seats again.');
          navigate(`/booking/${bookingState.show._id}`);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [bookingState, navigate]);

  if (!bookingState) return null;

  const { show, selectedSeats, seatDetails, ticketPrice, convenienceFee, tax, grandTotal } =
    bookingState;
  const movie = show.movieId || {};
  const theatre = show.theatreId || {};

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  const handlePayNow = async (e) => {
    e.preventDefault();
    setProcessing(true);
    setErrorMsg('');

    try {
      // 1. Process simulated payment
      const paymentRes = await api.post('/payments/process', {
        amount: grandTotal,
        paymentMethod,
        cardDetails: { cardLast4: cardNumber.replace(/\s+/g, '').slice(-4) },
        upiId,
      });

      if (!paymentRes.data.success) {
        throw new Error('Payment authorization failed');
      }

      // 2. Finalize Booking in Database
      const bookingRes = await api.post('/bookings', {
        showId: show._id,
        seatIds: selectedSeats,
        paymentMethod,
        paymentDetails: {
          cardLast4: cardNumber.replace(/\s+/g, '').slice(-4),
          upiId,
          bankName: selectedBank,
        },
      });

      if (bookingRes.data.success) {
        navigate(`/booking-success/${bookingRes.data.data._id}`, {
          state: { booking: bookingRes.data.data },
        });
      }
    } catch (err) {
      setErrorMsg(err.response?.data?.message || err.message || 'Payment processing failed');
      setProcessing(false);
    }
  };

  return (
    <div className="container py-4">
      {/* Top Banner with Countdown */}
      <div className="cinema-card p-3 mb-4 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2 border-danger border-opacity-50">
        <div className="d-flex align-items-center gap-2">
          <Lock size={18} className="text-warning" />
          <span className="text-white small fw-bold">
            Seats {selectedSeats.join(', ')} temporarily reserved for checkout
          </span>
        </div>
        <div className="d-flex align-items-center gap-2 text-warning fw-bold fs-6">
          <Timer size={18} />
          <span>
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </span>
        </div>
      </div>

      {errorMsg && (
        <div className="alert alert-danger d-flex align-items-center gap-2 mb-4" role="alert">
          <AlertCircle size={18} />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="row g-4">
        {/* Left Side: Customer & Payment Method Form */}
        <div className="col-12 col-lg-8">
          <div className="cinema-card p-4 mb-4">
            <h5 className="text-white fw-bold mb-3 pb-2 border-bottom border-secondary border-opacity-25">
              1. Contact Information
            </h5>
            <div className="row g-3">
              <div className="col-12 col-sm-4">
                <label className="text-secondary small mb-1">Full Name</label>
                <input
                  type="text"
                  className="form-control cinema-input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="col-12 col-sm-4">
                <label className="text-secondary small mb-1">Email Address</label>
                <input
                  type="email"
                  className="form-control cinema-input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="col-12 col-sm-4">
                <label className="text-secondary small mb-1">Mobile Phone</label>
                <input
                  type="tel"
                  className="form-control cinema-input"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
              </div>
            </div>
            <span className="text-secondary small d-block mt-2" style={{ fontSize: '11px' }}>
              Your e-ticket confirmation and SMS entry pass will be dispatched to this contact info.
            </span>
          </div>

          {/* Payment Method Selector */}
          <div className="cinema-card p-4">
            <h5 className="text-white fw-bold mb-3 pb-2 border-bottom border-secondary border-opacity-25">
              2. Select Payment Method
            </h5>

            {/* Payment Method Tabs */}
            <div className="d-flex flex-wrap gap-2 mb-4">
              <button
                type="button"
                className={`btn btn-sm rounded-3 px-3 py-2 d-flex align-items-center gap-2 transition ${
                  paymentMethod === 'credit_card'
                    ? 'glow-btn'
                    : 'btn-outline-secondary text-light'
                }`}
                onClick={() => setPaymentMethod('credit_card')}
              >
                <CreditCard size={16} /> Credit / Debit Card
              </button>

              <button
                type="button"
                className={`btn btn-sm rounded-3 px-3 py-2 d-flex align-items-center gap-2 transition ${
                  paymentMethod === 'upi' ? 'glow-btn' : 'btn-outline-secondary text-light'
                }`}
                onClick={() => setPaymentMethod('upi')}
              >
                <QrCode size={16} /> UPI / QR Scan
              </button>

              <button
                type="button"
                className={`btn btn-sm rounded-3 px-3 py-2 d-flex align-items-center gap-2 transition ${
                  paymentMethod === 'netbanking'
                    ? 'glow-btn'
                    : 'btn-outline-secondary text-light'
                }`}
                onClick={() => setPaymentMethod('netbanking')}
              >
                <Building size={16} /> Net Banking
              </button>

              <button
                type="button"
                className={`btn btn-sm rounded-3 px-3 py-2 d-flex align-items-center gap-2 transition ${
                  paymentMethod === 'wallet' ? 'glow-btn' : 'btn-outline-secondary text-light'
                }`}
                onClick={() => setPaymentMethod('wallet')}
              >
                <Wallet size={16} /> Mobile Wallet
              </button>
            </div>

            {/* Card Form */}
            {paymentMethod === 'credit_card' && (
              <form onSubmit={handlePayNow}>
                <div className="row g-3">
                  <div className="col-12">
                    <label className="text-secondary small mb-1">Card Number</label>
                    <input
                      type="text"
                      className="form-control cinema-input font-monospace"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="4242 •••• •••• 4242"
                      required
                    />
                  </div>
                  <div className="col-12 col-sm-6">
                    <label className="text-secondary small mb-1">Cardholder Name</label>
                    <input
                      type="text"
                      className="form-control cinema-input"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      placeholder="Name on card"
                      required
                    />
                  </div>
                  <div className="col-6 col-sm-3">
                    <label className="text-secondary small mb-1">Expiry</label>
                    <input
                      type="text"
                      className="form-control cinema-input font-monospace"
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      placeholder="MM/YY"
                      required
                    />
                  </div>
                  <div className="col-6 col-sm-3">
                    <label className="text-secondary small mb-1">CVV</label>
                    <input
                      type="password"
                      maxLength={4}
                      className="form-control cinema-input font-monospace"
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value)}
                      placeholder="•••"
                      required
                    />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-top border-secondary border-opacity-25 d-flex justify-content-between align-items-center">
                  <div className="d-flex align-items-center gap-2 text-secondary small">
                    <ShieldCheck size={16} className="text-success" />
                    <span>256-bit TLS Encrypted Simulated Gateway</span>
                  </div>

                  <button
                    type="submit"
                    className="btn glow-btn px-4 py-2.5 rounded-3 d-flex align-items-center gap-2"
                    disabled={processing}
                  >
                    {processing ? (
                      <>
                        <div className="spinner-border spinner-border-sm" role="status"></div>
                        <span>Processing ₹{grandTotal}...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle size={18} />
                        <span>Pay Securely ₹{grandTotal}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* UPI Option */}
            {paymentMethod === 'upi' && (
              <div>
                <div className="p-3 rounded bg-dark bg-opacity-50 border border-secondary border-opacity-25 mb-3">
                  <label className="text-secondary small mb-1">Enter VPA / UPI ID</label>
                  <div className="input-group">
                    <input
                      type="text"
                      className="form-control cinema-input font-monospace"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="username@bank"
                    />
                    <button
                      className="btn glow-btn px-4"
                      disabled={processing}
                      onClick={handlePayNow}
                    >
                      {processing ? 'Authorizing...' : `Pay ₹${grandTotal}`}
                    </button>
                  </div>
                </div>
                <div className="text-center py-3 border border-secondary border-opacity-25 rounded-3">
                  <p className="text-secondary small mb-2">Or scan with Google Pay / PhonePe / Paytm:</p>
                  <div className="p-2 bg-white d-inline-block rounded-3 shadow-sm">
                    <QrCode size={110} color="#0f172a" />
                  </div>
                </div>
              </div>
            )}

            {/* NetBanking Option */}
            {paymentMethod === 'netbanking' && (
              <div>
                <p className="text-secondary small mb-2">Select your retail bank:</p>
                <div className="row g-2 mb-4">
                  {['HDFC Bank', 'ICICI Bank', 'State Bank of India', 'Axis Bank', 'Kotak Mahindra'].map((b) => (
                    <div key={b} className="col-6 col-sm-4">
                      <button
                        type="button"
                        className={`btn w-100 py-2 rounded text-truncate text-start ${
                          selectedBank === b ? 'btn-danger' : 'btn-outline-secondary text-light'
                        }`}
                        onClick={() => setSelectedBank(b)}
                      >
                        {b}
                      </button>
                    </div>
                  ))}
                </div>
                <button
                  className="btn glow-btn w-100 py-2.5 rounded-3"
                  disabled={processing}
                  onClick={handlePayNow}
                >
                  {processing ? 'Connecting to Bank...' : `Proceed with ${selectedBank} (₹${grandTotal})`}
                </button>
              </div>
            )}

            {/* Wallet Option */}
            {paymentMethod === 'wallet' && (
              <div>
                <p className="text-secondary small mb-2">Select digital wallet:</p>
                <div className="d-flex flex-column gap-2 mb-4">
                  {['Paytm Wallet', 'Amazon Pay', 'PhonePe Wallet'].map((w) => (
                    <div
                      key={w}
                      className="p-3 rounded cinema-card d-flex justify-content-between align-items-center"
                      style={{ cursor: 'pointer' }}
                      onClick={handlePayNow}
                    >
                      <span className="text-white fw-bold">{w}</span>
                      <span className="badge badge-gold">Link & Pay ₹{grandTotal}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Order Review */}
        <div className="col-12 col-lg-4">
          <div className="cinema-card p-4 sticky-top" style={{ top: '80px' }}>
            <h5 className="fw-bold text-white mb-3 pb-2 border-bottom border-secondary border-opacity-25">
              Order Breakdown
            </h5>

            <div className="d-flex gap-3 mb-3">
              <img
                src={movie.poster}
                alt={movie.title}
                className="rounded-3 shadow-sm object-fit-cover"
                style={{ width: '60px', height: '85px' }}
              />
              <div>
                <h6 className="text-white fw-bold mb-1">{movie.title}</h6>
                <span className="text-secondary small d-block">{theatre.name}</span>
                <span className="text-secondary small d-block">
                  {show.showDate} • {show.showTime}
                </span>
                <span className="badge badge-gold mt-1">Seats: {selectedSeats.join(', ')}</span>
              </div>
            </div>

            <div className="border-top border-secondary border-opacity-25 pt-3 mb-3">
              <div className="d-flex justify-content-between text-secondary small mb-2">
                <span>Tickets ({selectedSeats.length} seats)</span>
                <span className="text-white">₹{ticketPrice}</span>
              </div>
              <div className="d-flex justify-content-between text-secondary small mb-2">
                <span>Convenience Fee</span>
                <span className="text-white">₹{convenienceFee}</span>
              </div>
              <div className="d-flex justify-content-between text-secondary small mb-2">
                <span>GST / Taxes (18%)</span>
                <span className="text-white">₹{tax}</span>
              </div>
              <div className="d-flex justify-content-between text-white fw-black fs-5 pt-2 border-top border-secondary border-opacity-25 mt-2">
                <span>Total Payable</span>
                <span className="text-warning">₹{grandTotal}</span>
              </div>
            </div>

            <div className="p-2.5 rounded bg-dark bg-opacity-50 border border-secondary border-opacity-25">
              <span className="text-secondary small d-block" style={{ fontSize: '11px' }}>
                Cancellation Policy: You can cancel up to 2 hours before showtime for an 85% refund credited instantly.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
