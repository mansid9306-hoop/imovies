import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import SeatMatrix from '../components/SeatMatrix';
import {
  Film,
  Calendar,
  Clock,
  MapPin,
  ArrowLeft,
  ShieldCheck,
  CreditCard,
  AlertCircle,
  Timer,
} from 'lucide-react';

const SeatBookingPage = () => {
  const { showId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { socket, joinShow, leaveShow } = useSocket();

  const [show, setShow] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [locking, setLocking] = useState(false);

  // Fetch show details
  const fetchShow = async () => {
    try {
      setLoading(true);
      const res = await api.get(`/shows/${showId}`);
      if (res.data.success) {
        setShow(res.data.data);
      }
    } catch (err) {
      setErrorMsg('Failed to load auditorium seating layout');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchShow();

    // Socket.io room subscription
    joinShow(showId);

    if (socket) {
      socket.on('seats_updated', (data) => {
        if (data.showId === showId) {
          setShow((prev) => (prev ? { ...prev, seatMatrix: data.seatMatrix, availableSeats: data.availableSeats } : prev));
        }
      });
    }

    return () => {
      leaveShow(showId);
      if (socket) {
        socket.off('seats_updated');
      }
    };
  }, [showId, socket]);

  // Handle seat click
  const handleSeatToggle = (seat) => {
    setErrorMsg('');
    if (selectedSeats.includes(seat.seatId)) {
      setSelectedSeats((prev) => prev.filter((id) => id !== seat.seatId));
    } else {
      if (selectedSeats.length >= 8) {
        setErrorMsg('Maximum 8 seats allowed per transaction');
        return;
      }
      setSelectedSeats((prev) => [...prev, seat.seatId]);
    }
  };

  if (loading) {
    return (
      <div className="d-flex align-items-center justify-content-center min-vh-50 py-5">
        <div className="spinner-border text-danger" role="status"></div>
      </div>
    );
  }

  if (!show) {
    return (
      <div className="container py-5 text-center">
        <h4 className="text-white">Show not found</h4>
        <Link to="/movies" className="btn btn-sm glow-btn mt-3">
          Explore Movies
        </Link>
      </div>
    );
  }

  const movie = show.movieId || {};
  const theatre = show.theatreId || {};

  // Calculate pricing breakdown
  const seatDetails = selectedSeats.map((seatId) => {
    const s = show.seatMatrix.find((item) => item.seatId === seatId);
    return {
      seatId,
      tier: s?.tier || 'standard',
      price: s?.price || 200,
    };
  });

  const ticketPrice = seatDetails.reduce((sum, item) => sum + item.price, 0);
  const convenienceFee = selectedSeats.length > 0 ? selectedSeats.length * 15 : 0;
  const tax = Math.round((ticketPrice + convenienceFee) * 0.18);
  const grandTotal = ticketPrice + convenienceFee + tax;

  // Proceed to payment & lock seats
  const handleProceedToPayment = async () => {
    if (!user) {
      navigate('/login', { state: { from: `/booking/${showId}` } });
      return;
    }

    if (selectedSeats.length === 0) {
      setErrorMsg('Please select at least one seat to continue');
      return;
    }

    setLocking(true);
    setErrorMsg('');

    try {
      const res = await api.post(`/shows/${showId}/lock-seats`, { seatIds: selectedSeats });
      if (res.data.success) {
        navigate('/checkout', {
          state: {
            show,
            selectedSeats,
            seatDetails,
            ticketPrice,
            convenienceFee,
            tax,
            grandTotal,
            lockExpiry: res.data.lockExpiry,
          },
        });
      }
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Selected seats became unavailable. Please select different seats.');
      // Refresh seats
      fetchShow();
    } finally {
      setLocking(false);
    }
  };

  return (
    <div className="container py-4">
      {/* Top Breadcrumb Navigation & Show Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary border-opacity-25">
        <div>
          <button
            className="btn btn-sm btn-link text-secondary text-decoration-none p-0 d-flex align-items-center gap-1 mb-2 hover-white"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft size={16} /> Back to Movie
          </button>
          <div className="d-flex align-items-center gap-2">
            <h3 className="fw-black text-white mb-0">{movie.title}</h3>
            <span className="badge badge-red">{movie.certificate || 'UA'}</span>
          </div>
          <div className="d-flex flex-wrap align-items-center gap-3 text-secondary small mt-1">
            <span className="text-light">{theatre.name} ({show.screenName})</span>
            <span>•</span>
            <span className="d-flex align-items-center gap-1 text-warning">
              <Calendar size={13} /> {show.showDate}
            </span>
            <span>•</span>
            <span className="d-flex align-items-center gap-1 text-info">
              <Clock size={13} /> {show.showTime}
            </span>
          </div>
        </div>

        {/* Live Status indicator */}
        <div className="d-flex align-items-center gap-2">
          <span
            className="rounded-circle bg-success"
            style={{ width: '8px', height: '8px', animation: 'pulse-locked 1.5s infinite' }}
          ></span>
          <span className="text-secondary small">Real-Time Seat Tracking Active</span>
        </div>
      </div>

      {errorMsg && (
        <div className="alert alert-danger d-flex align-items-center gap-2 mb-4" role="alert">
          <AlertCircle size={18} />
          <span>{errorMsg}</span>
        </div>
      )}

      <div className="row g-4">
        {/* Left Side: Seat Layout Matrix */}
        <div className="col-12 col-lg-8">
          <div className="cinema-card p-3 p-md-4">
            <SeatMatrix
              seatMatrix={show.seatMatrix}
              selectedSeats={selectedSeats}
              onSeatToggle={handleSeatToggle}
              pricing={show.pricing}
            />
          </div>
        </div>

        {/* Right Side: Order Summary & Checkout Card */}
        <div className="col-12 col-lg-4">
          <div className="cinema-card p-4 sticky-top" style={{ top: '80px' }}>
            <h5 className="fw-bold text-white mb-3 pb-2 border-bottom border-secondary border-opacity-25">
              Booking Summary
            </h5>

            {/* Movie Poster & Quick Info */}
            <div className="d-flex gap-3 mb-4">
              <img
                src={movie.poster}
                alt={movie.title}
                className="rounded-3 shadow-sm object-fit-cover"
                style={{ width: '65px', height: '90px' }}
              />
              <div>
                <h6 className="text-white fw-bold mb-1">{movie.title}</h6>
                <span className="text-secondary small d-block">{movie.language?.join(', ')}</span>
                <span className="text-secondary small d-block font-monospace">
                  {theatre.city} • {show.screenName}
                </span>
              </div>
            </div>

            {/* Selected Seats Pills */}
            <div className="mb-4">
              <label className="text-secondary small d-block mb-2">Selected Seats ({selectedSeats.length}):</label>
              {selectedSeats.length === 0 ? (
                <span className="text-secondary small fst-italic">No seats selected yet</span>
              ) : (
                <div className="d-flex flex-wrap gap-2">
                  {seatDetails.map((s) => (
                    <span key={s.seatId} className="badge badge-gold px-2.5 py-1.5 fs-6">
                      {s.seatId} <span className="small opacity-75">(₹{s.price})</span>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Price Calculations */}
            <div className="border-top border-secondary border-opacity-25 pt-3 mb-4">
              <div className="d-flex justify-content-between text-secondary small mb-2">
                <span>Tickets Base Amount</span>
                <span className="text-white">₹{ticketPrice}</span>
              </div>
              <div className="d-flex justify-content-between text-secondary small mb-2">
                <span>Convenience Fee (₹15/ticket)</span>
                <span className="text-white">₹{convenienceFee}</span>
              </div>
              <div className="d-flex justify-content-between text-secondary small mb-2">
                <span>Integrated GST (18%)</span>
                <span className="text-white">₹{tax}</span>
              </div>
              <div className="d-flex justify-content-between text-white fw-bold fs-5 pt-2 border-top border-secondary border-opacity-25 mt-2">
                <span>Grand Total</span>
                <span className="text-warning">₹{grandTotal}</span>
              </div>
            </div>

            {/* Checkout CTA */}
            <button
              className="btn glow-btn w-100 py-3 rounded-3 d-flex align-items-center justify-content-center gap-2"
              disabled={selectedSeats.length === 0 || locking}
              onClick={handleProceedToPayment}
            >
              {locking ? (
                <>
                  <div className="spinner-border spinner-border-sm" role="status"></div>
                  <span>Locking Seats...</span>
                </>
              ) : (
                <>
                  <CreditCard size={18} />
                  <span>Proceed to Payment</span>
                </>
              )}
            </button>

            <div className="text-center mt-3">
              <span className="text-secondary small d-flex align-items-center justify-content-center gap-1">
                <ShieldCheck size={14} className="text-success" /> 100% Secure Simulated Checkout
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SeatBookingPage;
