import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Film, User, Mail, Lock, Phone, AlertCircle, ArrowRight } from 'lucide-react';

const RegisterPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('user');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setSubmitting(true);
    const res = await register({ name, email, phone, password, role });
    setSubmitting(false);

    if (res.success) {
      navigate('/');
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-12 col-md-7 col-lg-6">
          <div className="cinema-card p-4 p-md-5">
            {/* Logo & Heading */}
            <div className="text-center mb-4">
              <div
                className="d-inline-flex align-items-center justify-content-center mb-2"
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 12,
                  background: 'linear-gradient(135deg, #e50914 0%, #b80710 100%)',
                  boxShadow: '0 0 20px rgba(229, 9, 20, 0.4)',
                }}
              >
                <Film color="#ffffff" size={28} />
              </div>
              <h3 className="fw-black text-white mb-1">Create an Account</h3>
              <p className="text-secondary small">
                Join IMovies to book cinema tickets with zero hassle
              </p>
            </div>

            {error && (
              <div className="alert alert-danger d-flex align-items-center gap-2 mb-3" role="alert">
                <AlertCircle size={16} />
                <span className="small">{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <div className="row g-3">
                <div className="col-12">
                  <label className="text-secondary small mb-1">Full Name</label>
                  <div className="position-relative">
                    <User
                      size={16}
                      className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                    />
                    <input
                      type="text"
                      className="form-control cinema-input ps-5"
                      placeholder="Jane Doe"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Email Address</label>
                  <div className="position-relative">
                    <Mail
                      size={16}
                      className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                    />
                    <input
                      type="email"
                      className="form-control cinema-input ps-5"
                      placeholder="jane@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Mobile Phone</label>
                  <div className="position-relative">
                    <Phone
                      size={16}
                      className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                    />
                    <input
                      type="tel"
                      className="form-control cinema-input ps-5"
                      placeholder="+91 98765 43210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Password</label>
                  <div className="position-relative">
                    <Lock
                      size={16}
                      className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                    />
                    <input
                      type="password"
                      className="form-control cinema-input ps-5"
                      placeholder="At least 6 chars"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="col-12 col-sm-6">
                  <label className="text-secondary small mb-1">Confirm Password</label>
                  <div className="position-relative">
                    <Lock
                      size={16}
                      className="position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"
                    />
                    <input
                      type="password"
                      className="form-control cinema-input ps-5"
                      placeholder="Repeat password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="col-12">
                  <label className="text-secondary small mb-1">Account Role</label>
                  <select
                    className="form-select cinema-input text-white"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                  >
                    <option value="user">Cinema Customer (Book tickets, manage history)</option>
                    <option value="admin">Cinema Manager / Admin (Manage movies, shows, analytics)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="btn glow-btn w-100 py-2.5 rounded-3 mt-4 mb-3 d-flex align-items-center justify-content-center gap-2"
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <div className="spinner-border spinner-border-sm" role="status"></div>
                    <span>Creating Account...</span>
                  </>
                ) : (
                  <>
                    <span>Create Account</span>
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>

            <div className="text-center mt-3 pt-3 border-top border-secondary border-opacity-25">
              <span className="text-secondary small">
                Already have an account?{' '}
                <Link to="/login" className="text-danger fw-bold text-decoration-none">
                  Sign In
                </Link>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
