import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

import { connectDB } from './config/db.js';
import { notFound, errorHandler } from './middleware/errorMiddleware.js';
import { apiLimiter } from './middleware/rateLimiter.js';

import authRoutes from './routes/authRoutes.js';
import movieRoutes from './routes/movieRoutes.js';
import theatreRoutes from './routes/theatreRoutes.js';
import showRoutes from './routes/showRoutes.js';
import bookingRoutes from './routes/bookingRoutes.js';
import paymentRoutes from './routes/paymentRoutes.js';
import adminRoutes from './routes/adminRoutes.js';

import { autoSeedIfEmpty } from './seeds/seedData.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);

// Initialize Socket.io
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
  },
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Attach Socket.io to request object
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Apply rate limiter to general API
app.use('/api', apiLimiter);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    app: 'IMovies API Server',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
  });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/movies', movieRoutes);
app.use('/api/theatres', theatreRoutes);
app.use('/api/shows', showRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/admin', adminRoutes);

// Socket.io Real-time Seat Tracking
io.on('connection', (socket) => {
  // Join a specific show room
  socket.on('join_show', (showId) => {
    socket.join(`show_${showId}`);
  });

  // Leave show room
  socket.on('leave_show', (showId) => {
    socket.leave(`show_${showId}`);
  });

  // Client emits tentative seat hover or click
  socket.on('seat_selected', ({ showId, seatId, userId }) => {
    socket.to(`show_${showId}`).emit('seat_live_status', { seatId, status: 'selecting', userId });
  });

  socket.on('disconnect', () => {
    // handled cleanly
  });
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

// Connect to DB, seed default catalog if empty, and listen
connectDB().then(async () => {
  try {
    await autoSeedIfEmpty();
  } catch (err) {
    console.error('[Seed] Notice during auto-seeding:', err.message);
  }

  server.listen(PORT, () => {
    console.log(`[IMovies Server] Running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
    console.log(`[IMovies Server] API root: http://localhost:${PORT}/api`);
  });
});
