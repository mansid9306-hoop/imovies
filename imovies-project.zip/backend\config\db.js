import mongoose from 'mongoose';

export const connectDB = async () => {
  const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/imovies';

  if (mongoUri.includes('<db_password>')) {
    console.warn('--------------------------------------------------------------------------------');
    console.warn('[MongoDB Atlas Notice]');
    console.warn('Your MONGO_URI contains the placeholder "<db_password>".');
    console.warn('Please replace "<db_password>" in your backend/.env file with your actual Atlas password.');
    console.warn('Running in High-Performance Local Evaluation Mode in the meantime.');
    console.warn('--------------------------------------------------------------------------------');
    return null;
  }

  try {
    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 8000,
    });
    console.log(`[MongoDB] Connected successfully to host: ${conn.connection.host} (${conn.connection.name})`);
    return conn;
  } catch (err) {
    console.warn(`[MongoDB] Connection to Atlas/remote (${mongoUri.replace(/:([^:@]+)@/, ':****@')}) failed: ${err.message}`);
    console.log('[MongoDB] Running in High-Performance Built-in Document Store Mode (Zero-Setup Evaluation).');
    return null;
  }
};
